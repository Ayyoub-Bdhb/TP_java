public class Racaillou extends Pokemon {

    @Override
    public String getEspece() {
        return "Racaillou";
    }

    public Racaillou(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(74,"Racaillou","Racaillou","roche","sol",80,100,20,40  );
    }

    public static void main(String[] args) {
        Racaillou Racaillou = new Racaillou(74, "roche", "sol", 80, 100, 40);
        System.out.println(Racaillou);
    }
}
