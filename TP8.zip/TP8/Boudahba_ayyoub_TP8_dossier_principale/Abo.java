public class Abo extends Pokemon {

    @Override
    public String getEspece() {
        return "Abo";
    }

    public Abo(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(23,"Abo","Abo","poison","",60,44,55,35  );
    }

    public static void main(String[] args) {
        Abo Abo = new Abo(23, "poison", "", 60, 44, 35);
        System.out.println(Abo);
    }
}
