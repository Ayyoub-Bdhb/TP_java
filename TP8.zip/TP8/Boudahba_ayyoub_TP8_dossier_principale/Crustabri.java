public class Crustabri extends Pokemon {

    @Override
    public String getEspece() {
        return "Crustabri";
    }

    public Crustabri(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(91,"Crustabri","Crustabri","eau","glace",95,180,70,50  );
    }

    public static void main(String[] args) {
        Crustabri Crustabri = new Crustabri(91, "eau", "glace", 95, 180, 50);
        System.out.println(Crustabri);
    }
}
