public class Aspicot extends Pokemon {

    @Override
    public String getEspece() {
        return "Aspicot";
    }

    public Aspicot(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(13,"Aspicot","Aspicot","insecte","poison",35,30,50,40  );
    }

    public static void main(String[] args) {
        Aspicot Aspicot = new Aspicot(13, "insecte", "poison", 35, 30, 40);
        System.out.println(Aspicot);
    }
}
