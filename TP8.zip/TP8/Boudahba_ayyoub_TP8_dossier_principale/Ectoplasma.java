public class Ectoplasma extends Pokemon {

    @Override
    public String getEspece() {
        return "Ectoplasma";
    }

    public Ectoplasma(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(94,"Ectoplasma","Ectoplasma","spectre","poison",65,60,110,60  );
    }

    public static void main(String[] args) {
        Ectoplasma Ectoplasma = new Ectoplasma(94, "spectre", "poison", 65, 60, 60);
        System.out.println(Ectoplasma);
    }
}
