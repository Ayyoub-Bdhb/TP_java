public class Nosferapti extends Pokemon {

    @Override
    public String getEspece() {
        return "Nosferapti";
    }

    public Nosferapti(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(41,"Nosferapti","Nosferapti","poison","vol",45,35,55,40  );
    }

    public static void main(String[] args) {
        Nosferapti Nosferapti = new Nosferapti(41, "poison", "vol", 45, 35, 40);
        System.out.println(Nosferapti);
    }
}
