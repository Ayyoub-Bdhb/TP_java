 abstract class Pokemon{

   protected int numPokemon;
   protected String especes;
   protected String nomPokemon;
   protected String typePokemon1; 
   protected String typePokemon2; 
   protected int attPokemon;
   protected int defPokemon;
   private   int vitessePokemon;
   protected int pvPokemon; 

    public Pokemon(){
        this.numPokemon = 1;
        this.especes    = Type.getEspece(25);
        this.nomPokemon = "pika_pika";
        this.typePokemon1 = Type.getNomType(3);
        this.typePokemon2 = Type.getNomType(2);
        this.attPokemon   = 64;
        this.defPokemon   = 58;
        this.vitessePokemon = 70;
        this.pvPokemon      = 62;
    }





        public Pokemon(int numPokemon, String especes, String nomPokemon, String typePokemon1, String typePokemon2,
        int attPokemon, int defPokemon, int vitessePokemon, int pvPokemon) {
        this.numPokemon = numPokemon;
        this.especes    = especes;
        this.nomPokemon = nomPokemon;
        this.typePokemon1 = typePokemon1;
        this.typePokemon2 = typePokemon2;
        this.attPokemon = attPokemon;
        this.defPokemon = defPokemon;
        this.vitessePokemon = vitessePokemon;
        this.pvPokemon = pvPokemon;
}




public String toString() {
    return "Numéro: " + numPokemon + "\n" +
           "Espece: " + getEspece() + "\n"+
           "Type 1: " + typePokemon1 + "\n" +
           "Type 2: " + (typePokemon2.isEmpty() ? "ø" : typePokemon2) + "\n" +
           "PV: " + pvPokemon + "\n" +
           "Att: " + attPokemon + "\n" +
           "Def: " + defPokemon + "\n";
}

public boolean equals(Object o) {
    if (!(o instanceof Pokemon)) {
        return false;
    }
    Pokemon p = (Pokemon) o;
    return this.numPokemon == p.numPokemon &&
            this.especes.equals(p.especes) &&
            this.nomPokemon.equals(p.nomPokemon) &&
            this.typePokemon1.equals(p.typePokemon1) &&
            this.typePokemon2.equals(p.typePokemon2) &&
            this.attPokemon == p.attPokemon &&
            this.defPokemon == p.defPokemon &&
            this.vitessePokemon == p.vitessePokemon &&
            this.pvPokemon == p.pvPokemon;
}

public void attaque(Pokemon pokemon1){
    if (this.vitessePokemon < pokemon1.vitessePokemon){
        this.pvPokemon = this.pvPokemon - (pokemon1.attPokemon - this.defPokemon);
        if (this.pvPokemon > 0){
            pokemon1.pvPokemon = pokemon1.pvPokemon - (this.attPokemon - pokemon1.defPokemon);
            if (pokemon1.pvPokemon <= 0){
                System.out.println(pokemon1.especes + " est retourné dans sa pokeball\n" + this.especes + "à gagné le combat");
            }
        }
        else{ System.out.println(this.especes + "est retourné dans sa pokeball\n" + pokemon1.especes + "à gagné le combat");
    }
}

    else if (this.vitessePokemon >= pokemon1.vitessePokemon){
        pokemon1.pvPokemon = pokemon1.pvPokemon - (this.attPokemon - pokemon1.defPokemon);
        System.out.println(this + "\n");
        System.out.println(pokemon1 + "\n");
        if (pokemon1.pvPokemon > 0){
            this.pvPokemon = this.pvPokemon - (pokemon1.attPokemon - this.defPokemon);
            System.out.println(this + "\n");
            System.out.println(pokemon1 + "\n");
            if (this.pvPokemon <= 0 ){
                System.out.println(this.especes + " est retourné dans sa pokeball\n" + pokemon1.especes + " à gagné le combat");
            }

        }
        else{ System.out.println(pokemon1.especes + " est retourné dans sa pokeball\n" + this.especes + " à gagné le combat");

    }
    }

    
}

public int getpvPokemon(){
    return this.pvPokemon;
}

abstract public  String getEspece();





































    
}