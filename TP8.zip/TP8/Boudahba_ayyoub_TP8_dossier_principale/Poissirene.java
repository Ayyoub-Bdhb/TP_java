public class Poissirene extends Pokemon {

    @Override
    public String getEspece() {
        return "Poissirène";
    }

    public Poissirene(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(118,"Poissirène","Poissirène","eau","",67,60,63,45  );
    }

    public static void main(String[] args) {
        Poissirene Poissirene = new Poissirene(118, "eau", "", 67, 60, 45);
        System.out.println(Poissirene);
    }
}
