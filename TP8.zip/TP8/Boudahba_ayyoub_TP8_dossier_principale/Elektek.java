public class Elektek extends Pokemon {

    @Override
    public String getEspece() {
        return "Élektek";
    }

    public Elektek(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(125,"Élektek","Élektek","electrik","",83,57,105,65  );
    }

    public static void main(String[] args) {
        Elektek Elektek = new Elektek(125, "electrik", "", 83, 57, 65);
        System.out.println(Elektek);
    }
}
