public class Colossinge extends Pokemon {

    @Override
    public String getEspece() {
        return "Colossinge";
    }

    public Colossinge(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(57,"Colossinge","Colossinge","combat","",105,60,95,65  );
    }

    public static void main(String[] args) {
        Colossinge Colossinge = new Colossinge(57, "combat", "", 105, 60, 65);
        System.out.println(Colossinge);
    }
}
