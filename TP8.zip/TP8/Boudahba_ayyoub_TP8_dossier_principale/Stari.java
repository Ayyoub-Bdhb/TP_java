public class Stari extends Pokemon {

    @Override
    public String getEspece() {
        return "Stari";
    }

    public Stari(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(120,"Stari","Stari","eau","",45,55,85,30  );
    }

    public static void main(String[] args) {
        Stari Stari = new Stari(120, "eau", "", 45, 55, 30);
        System.out.println(Stari);
    }
}
