public class Canarticho extends Pokemon {

    @Override
    public String getEspece() {
        return "Canarticho";
    }

    public Canarticho(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(83,"Canarticho","Canarticho","normal","vol",65,55,60,52  );
    }

    public static void main(String[] args) {
        Canarticho Canarticho = new Canarticho(83, "normal", "vol", 65, 55, 52);
        System.out.println(Canarticho);
    }
}
