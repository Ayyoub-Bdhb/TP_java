public class Position {
    private int x;
    private int y;

    public Position(int x, int y) {
        this.x = x;
        this.y = y;
    }

    // constructeur par défaut
    public Position(){
        this.x = 0;
        this.y = 0;
    }

    // Constructeur par copie
    public Position(Position pos) {
        this.x = pos.x;
        this.y = pos.y;
    }

    public Position(String lettre , int chiffre){
        this.x = (int) lettre.charAt(0) - 'A';
        this.y = chiffre - 1;

    }



    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }

    public void setX(int x) {
        this.x = x;
    }
    public void setY(int y) {
        this.y = y;
    }
    
    public boolean equals(Object pos){
        if (!(pos instanceof Pokemon)) {
            return false;
        }
        Position p = (Position) pos;
        return this.x == p.x && this.y == p.y;
    }

    public String toString() {
        char lettre = (char) ('A' + x); // Convertit x en lettre (0 -> 'A', 1 -> 'B', etc.)
        int chiffre = y + 1; // Convertit y en chiffre (0 -> 1, 1 -> 2, etc.)
        return lettre + "" + chiffre; // Concatène la lettre et le chiffre
    }


    public static void main(String[] args) {
    
        Position pos3 = new Position();
        System.out.println(pos3);
    }
}

