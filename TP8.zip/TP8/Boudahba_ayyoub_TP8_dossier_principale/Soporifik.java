public class Soporifik extends Pokemon {

    @Override
    public String getEspece() {
        return "Soporifik";
    }

    public Soporifik(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(96,"Soporifik","Soporifik","psy","",48,45,42,60  );
    }

    public static void main(String[] args) {
        Soporifik Soporifik = new Soporifik(96, "psy", "", 48, 45, 60);
        System.out.println(Soporifik);
    }
}
