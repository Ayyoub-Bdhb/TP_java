public class Insecateur extends Pokemon {

    @Override
    public String getEspece() {
        return "Insécateur";
    }

    public Insecateur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(123,"Insécateur","Insécateur","insecte","vol",110,80,105,70  );
    }

    public static void main(String[] args) {
        Insecateur Insecateur = new Insecateur(123, "insecte", "vol", 110, 80, 70);
        System.out.println(Insecateur);
    }
}
