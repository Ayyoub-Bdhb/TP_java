public class Rattata extends Pokemon {

    @Override
    public String getEspece() {
        return "Rattata";
    }

    public Rattata(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(19,"Rattata","Rattata","normal","",56,35,72,30  );
    }

    public static void main(String[] args) {
        Rattata Rattata = new Rattata(19, "normal", "", 56, 35, 30);
        System.out.println(Rattata);
    }
}
