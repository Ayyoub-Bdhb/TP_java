public class Dodrio extends Pokemon {

    @Override
    public String getEspece() {
        return "Dodrio";
    }

    public Dodrio(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(85,"Dodrio","Dodrio","normal","vol",110,70,100,60  );
    }

    public static void main(String[] args) {
        Dodrio Dodrio = new Dodrio(85, "normal", "vol", 110, 70, 60);
        System.out.println(Dodrio);
    }
}
