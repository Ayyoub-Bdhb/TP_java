public class Amonita extends Pokemon {

    @Override
    public String getEspece() {
        return "Amonita";
    }

    public Amonita(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(138,"Amonita","Amonita","roche","eau",40,100,35,35  );
    }

    public static void main(String[] args) {
        Amonita Amonita = new Amonita(138, "roche", "eau", 40, 100, 35);
        System.out.println(Amonita);
    }
}
