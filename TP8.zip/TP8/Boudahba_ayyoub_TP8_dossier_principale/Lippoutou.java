public class Lippoutou extends Pokemon {

    @Override
    public String getEspece() {
        return "Lippoutou";
    }

    public Lippoutou(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(124,"Lippoutou","Lippoutou","glace","psy",50,35,95,65  );
    }

    public static void main(String[] args) {
        Lippoutou Lippoutou = new Lippoutou(124, "glace", "psy", 50, 35, 65);
        System.out.println(Lippoutou);
    }
}
