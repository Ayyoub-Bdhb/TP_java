public class Grotadmorv extends Pokemon {

    @Override
    public String getEspece() {
        return "Grotadmorv";
    }

    public Grotadmorv(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(89,"Grotadmorv","Grotadmorv","poison","",105,75,50,105  );
    }

    public static void main(String[] args) {
        Grotadmorv Grotadmorv = new Grotadmorv(89, "poison", "", 105, 75, 105);
        System.out.println(Grotadmorv);
    }
}
