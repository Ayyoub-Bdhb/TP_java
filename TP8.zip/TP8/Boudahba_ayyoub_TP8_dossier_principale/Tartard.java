public class Tartard extends Pokemon {

    @Override
    public String getEspece() {
        return "Tartard";
    }

    public Tartard(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(62,"Tartard","Tartard","eau","combat",85,95,70,90  );
    }

    public static void main(String[] args) {
        Tartard Tartard = new Tartard(62, "eau", "combat", 85, 95, 90);
        System.out.println(Tartard);
    }
}
