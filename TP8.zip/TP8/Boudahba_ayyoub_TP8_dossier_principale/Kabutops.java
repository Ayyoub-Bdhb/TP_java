public class Kabutops extends Pokemon {

    @Override
    public String getEspece() {
        return "Kabutops";
    }

    public Kabutops(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(141,"Kabutops","Kabutops","roche","eau",115,105,80,60  );
    }

    public static void main(String[] args) {
        Kabutops Kabutops = new Kabutops(141, "roche", "eau", 115, 105, 60);
        System.out.println(Kabutops);
    }
}
