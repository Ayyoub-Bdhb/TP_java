public class Miaouss extends Pokemon {

    @Override
    public String getEspece() {
        return "Miaouss";
    }

    public Miaouss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(52,"Miaouss","Miaouss","normal","",45,35,90,40  );
    }

    public static void main(String[] args) {
        Miaouss Miaouss = new Miaouss(52, "normal", "", 45, 35, 40);
        System.out.println(Miaouss);
    }
}
