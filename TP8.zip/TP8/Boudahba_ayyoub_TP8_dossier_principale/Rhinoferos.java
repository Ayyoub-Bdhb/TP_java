public class Rhinoferos extends Pokemon {

    @Override
    public String getEspece() {
        return "Rhinoféros";
    }

    public Rhinoferos(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(112,"Rhinoféros","Rhinoféros","sol","roche",130,120,40,105  );
    }

    public static void main(String[] args) {
        Rhinoferos Rhinoferos = new Rhinoferos(112, "sol", "roche", 130, 120, 105);
        System.out.println(Rhinoferos);
    }
}
