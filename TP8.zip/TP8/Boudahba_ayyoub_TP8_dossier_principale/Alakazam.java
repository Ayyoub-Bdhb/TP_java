public class Alakazam extends Pokemon {

    @Override
    public String getEspece() {
        return "Alakazam";
    }

    public Alakazam(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(65,"Alakazam","Alakazam","psy","",50,45,120,55  );
    }

    public static void main(String[] args) {
        Alakazam Alakazam = new Alakazam(65, "psy", "", 50, 45, 55);
        System.out.println(Alakazam);
    }
}
