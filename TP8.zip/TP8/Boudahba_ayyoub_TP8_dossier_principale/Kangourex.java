public class Kangourex extends Pokemon {

    @Override
    public String getEspece() {
        return "Kangourex";
    }

    public Kangourex(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(115,"Kangourex","Kangourex","normal","",95,80,90,105  );
    }

    public static void main(String[] args) {
        Kangourex Kangourex = new Kangourex(115, "normal", "", 95, 80, 105);
        System.out.println(Kangourex);
    }
}
