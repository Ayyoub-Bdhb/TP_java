public class Tentacruel extends Pokemon {

    @Override
    public String getEspece() {
        return "Tentacruel";
    }

    public Tentacruel(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(73,"Tentacruel","Tentacruel","eau","poison",70,65,100,80  );
    }

    public static void main(String[] args) {
        Tentacruel Tentacruel = new Tentacruel(73, "eau", "poison", 70, 65, 80);
        System.out.println(Tentacruel);
    }
}
