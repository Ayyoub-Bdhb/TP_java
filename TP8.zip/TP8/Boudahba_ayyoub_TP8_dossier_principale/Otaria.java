public class Otaria extends Pokemon {

    @Override
    public String getEspece() {
        return "Otaria";
    }

    public Otaria(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(86,"Otaria","Otaria","eau","",45,55,45,65  );
    }

    public static void main(String[] args) {
        Otaria Otaria = new Otaria(86, "eau", "", 45, 55, 65);
        System.out.println(Otaria);
    }
}
