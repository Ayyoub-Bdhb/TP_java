public class Artikodin extends Pokemon {

    @Override
    public String getEspece() {
        return "Artikodin";
    }

    public Artikodin(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(144,"Artikodin","Artikodin","glace","vol",85,100,85,90  );
    }

    public static void main(String[] args) {
        Artikodin Artikodin = new Artikodin(144, "glace", "vol", 85, 100, 90);
        System.out.println(Artikodin);
    }
}
