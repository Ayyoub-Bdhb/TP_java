public class Noeunoeuf extends Pokemon {

    @Override
    public String getEspece() {
        return "Noeunoeuf";
    }

    public Noeunoeuf(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(102,"Noeunoeuf","Noeunoeuf","plante","psy",40,80,40,60  );
    }

    public static void main(String[] args) {
        Noeunoeuf Noeunoeuf = new Noeunoeuf(102, "plante", "psy", 40, 80, 60);
        System.out.println(Noeunoeuf);
    }
}
