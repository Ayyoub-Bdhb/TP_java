public class Voltorbe extends Pokemon {

    @Override
    public String getEspece() {
        return "Voltorbe";
    }

    public Voltorbe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(100,"Voltorbe","Voltorbe","electrik","",30,50,100,40  );
    }

    public static void main(String[] args) {
        Voltorbe Voltorbe = new Voltorbe(100, "electrik", "", 30, 50, 40);
        System.out.println(Voltorbe);
    }
}
