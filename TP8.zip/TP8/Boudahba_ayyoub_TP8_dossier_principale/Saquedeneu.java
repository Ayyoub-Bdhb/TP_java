public class Saquedeneu extends Pokemon {

    @Override
    public String getEspece() {
        return "Saquedeneu";
    }

    public Saquedeneu(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(114,"Saquedeneu","Saquedeneu","plante","",55,115,60,65  );
    }

    public static void main(String[] args) {
        Saquedeneu Saquedeneu = new Saquedeneu(114, "plante", "", 55, 115, 65);
        System.out.println(Saquedeneu);
    }
}
