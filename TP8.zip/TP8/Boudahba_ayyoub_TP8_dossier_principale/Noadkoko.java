public class Noadkoko extends Pokemon {

    @Override
    public String getEspece() {
        return "Noadkoko";
    }

    public Noadkoko(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(103,"Noadkoko","Noadkoko","plante","psy",95,85,55,95  );
    }

    public static void main(String[] args) {
        Noadkoko Noadkoko = new Noadkoko(103, "plante", "psy", 95, 85, 95);
        System.out.println(Noadkoko);
    }
}
