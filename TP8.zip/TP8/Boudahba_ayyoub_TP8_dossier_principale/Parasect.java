public class Parasect extends Pokemon {

    @Override
    public String getEspece() {
        return "Parasect";
    }

    public Parasect(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(47,"Parasect","Parasect","insecte","plante",95,80,30,60  );
    }

    public static void main(String[] args) {
        Parasect Parasect = new Parasect(47, "insecte", "plante", 95, 80, 60);
        System.out.println(Parasect);
    }
}
