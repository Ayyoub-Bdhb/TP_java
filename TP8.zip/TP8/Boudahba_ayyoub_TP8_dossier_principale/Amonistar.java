public class Amonistar extends Pokemon {

    @Override
    public String getEspece() {
        return "Amonistar";
    }

    public Amonistar(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(139,"Amonistar","Amonistar","roche","eau",60,125,55,70  );
    }

    public static void main(String[] args) {
        Amonistar Amonistar = new Amonistar(139, "roche", "eau", 60, 125, 70);
        System.out.println(Amonistar);
    }
}
