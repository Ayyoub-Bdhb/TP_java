public class Hypnomade extends Pokemon {

    @Override
    public String getEspece() {
        return "Hypnomade";
    }

    public Hypnomade(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(97,"Hypnomade","Hypnomade","psy","",73,70,67,85  );
    }

    public static void main(String[] args) {
        Hypnomade Hypnomade = new Hypnomade(97, "psy", "", 73, 70, 85);
        System.out.println(Hypnomade);
    }
}
