public class Mystherbe extends Pokemon {

    @Override
    public String getEspece() {
        return "Mystherbe";
    }

    public Mystherbe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(43,"Mystherbe","Mystherbe","plante","poison",50,55,30,45  );
    }

    public static void main(String[] args) {
        Mystherbe Mystherbe = new Mystherbe(43, "plante", "poison", 50, 55, 45);
        System.out.println(Mystherbe);
    }
}
