public class Persian extends Pokemon {

    @Override
    public String getEspece() {
        return "Persian";
    }

    public Persian(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(53,"Persian","Persian","normal","",70,60,115,65  );
    }

    public static void main(String[] args) {
        Persian Persian = new Persian(53, "normal", "", 70, 60, 65);
        System.out.println(Persian);
    }
}
