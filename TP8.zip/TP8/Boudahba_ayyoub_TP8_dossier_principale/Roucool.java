public class Roucool extends Pokemon {

    @Override
    public String getEspece() {
        return "Roucool";
    }

    public Roucool(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(16,"Roucool","Roucool","normal","vol",45,40,56,40  );
    }

    public static void main(String[] args) {
        Roucool Roucool = new Roucool(16, "normal", "vol", 45, 40, 40);
        System.out.println(Roucool);
    }
}
