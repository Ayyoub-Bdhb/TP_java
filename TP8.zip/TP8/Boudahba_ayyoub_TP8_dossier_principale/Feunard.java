public class Feunard extends Pokemon {

    @Override
    public String getEspece() {
        return "Feunard";
    }

    public Feunard(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(38,"Feunard","Feunard","feu","",76,75,100,73  );
    }

    public static void main(String[] args) {
        Feunard Feunard = new Feunard(38, "feu", "", 76, 75, 73);
        System.out.println(Feunard);
    }
}
