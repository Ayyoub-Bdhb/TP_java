public class Gravalanch extends Pokemon {

    @Override
    public String getEspece() {
        return "Gravalanch";
    }

    public Gravalanch(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(75,"Gravalanch","Gravalanch","roche","sol",95,115,35,55  );
    }

    public static void main(String[] args) {
        Gravalanch Gravalanch = new Gravalanch(75, "roche", "sol", 95, 115, 55);
        System.out.println(Gravalanch);
    }
}
