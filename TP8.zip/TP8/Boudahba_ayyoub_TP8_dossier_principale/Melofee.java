public class Melofee extends Pokemon {

    @Override
    public String getEspece() {
        return "Mélofée";
    }

    public Melofee(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(35,"Mélofée","Mélofée","normal","",45,48,35,70  );
    }

    public static void main(String[] args) {
        Melofee Melofee = new Melofee(35, "normal", "", 45, 48, 70);
        System.out.println(Melofee);
    }
}
