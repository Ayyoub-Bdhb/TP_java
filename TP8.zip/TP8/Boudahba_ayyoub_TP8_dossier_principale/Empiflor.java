public class Empiflor extends Pokemon {

    @Override
    public String getEspece() {
        return "Empiflor";
    }

    public Empiflor(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(71,"Empiflor","Empiflor","plante","poison",105,65,70,80  );
    }

    public static void main(String[] args) {
        Empiflor Empiflor = new Empiflor(71, "plante", "poison", 105, 65, 80);
        System.out.println(Empiflor);
    }
}
