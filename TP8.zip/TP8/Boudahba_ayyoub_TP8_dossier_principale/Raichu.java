public class Raichu extends Pokemon {

    @Override
    public String getEspece() {
        return "Raichu";
    }

    public Raichu(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(26,"Raichu","Raichu","electrik","",90,55,100,60  );
    }

    public static void main(String[] args) {
        Raichu Raichu = new Raichu(26, "electrik", "", 90, 55, 60);
        System.out.println(Raichu);
    }
}
