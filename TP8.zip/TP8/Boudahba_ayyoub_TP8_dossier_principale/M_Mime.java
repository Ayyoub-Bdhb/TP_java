public class M_Mime extends Pokemon {

    @Override
    public String getEspece() {
        return "M. Mime";
    }

    public M_Mime(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(122,"M. Mime","M. Mime","psy","",45,65,90,40  );
    }

    public static void main(String[] args) {
        M_Mime M_Mime = new M_Mime(122, "psy", "", 45, 65, 40);
        System.out.println(M_Mime);
    }
}
