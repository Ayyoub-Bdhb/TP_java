public class Carapuce extends Pokemon {

    @Override
    public String getEspece() {
        return "Carapuce";
    }

    public Carapuce(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(7,"Carapuce","Carapuce","eau","",48,65,43,44  );
    }

    public static void main(String[] args) {
        Carapuce Carapuce = new Carapuce(7, "eau", "", 48, 65, 44);
        System.out.println(Carapuce);
    }
}
