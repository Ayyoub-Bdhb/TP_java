public class Sulfura extends Pokemon {

    @Override
    public String getEspece() {
        return "Sulfura";
    }

    public Sulfura(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(146,"Sulfura","Sulfura","feu","vol",100,90,90,90  );
    }

    public static void main(String[] args) {
        Sulfura Sulfura = new Sulfura(146, "feu", "vol", 100, 90, 90);
        System.out.println(Sulfura);
    }
}
