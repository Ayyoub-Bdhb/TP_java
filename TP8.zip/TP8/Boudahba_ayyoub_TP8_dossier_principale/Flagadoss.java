public class Flagadoss extends Pokemon {

    @Override
    public String getEspece() {
        return "Flagadoss";
    }

    public Flagadoss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(80,"Flagadoss","Flagadoss","eau","psy",75,110,30,95  );
    }

    public static void main(String[] args) {
        Flagadoss Flagadoss = new Flagadoss(80, "eau", "psy", 75, 110, 95);
        System.out.println(Flagadoss);
    }
}
