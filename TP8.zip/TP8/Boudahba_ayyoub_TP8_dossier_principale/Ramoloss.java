public class Ramoloss extends Pokemon {

    @Override
    public String getEspece() {
        return "Ramoloss";
    }

    public Ramoloss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(79,"Ramoloss","Ramoloss","eau","psy",65,65,15,90  );
    }

    public static void main(String[] args) {
        Ramoloss Ramoloss = new Ramoloss(79, "eau", "psy", 65, 65, 90);
        System.out.println(Ramoloss);
    }
}
