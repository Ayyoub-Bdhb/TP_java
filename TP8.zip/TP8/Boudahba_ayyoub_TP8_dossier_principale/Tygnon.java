public class Tygnon extends Pokemon {

    @Override
    public String getEspece() {
        return "Tygnon";
    }

    public Tygnon(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(107,"Tygnon","Tygnon","combat","",105,79,76,50  );
    }

    public static void main(String[] args) {
        Tygnon Tygnon = new Tygnon(107, "combat", "", 105, 79, 50);
        System.out.println(Tygnon);
    }
}
