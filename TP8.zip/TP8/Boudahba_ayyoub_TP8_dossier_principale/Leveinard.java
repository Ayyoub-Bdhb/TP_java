public class Leveinard extends Pokemon {

    @Override
    public String getEspece() {
        return "Leveinard";
    }

    public Leveinard(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(113,"Leveinard","Leveinard","normal","",5,5,50,250  );
    }

    public static void main(String[] args) {
        Leveinard Leveinard = new Leveinard(113, "normal", "", 5, 5, 250);
        System.out.println(Leveinard);
    }
}
