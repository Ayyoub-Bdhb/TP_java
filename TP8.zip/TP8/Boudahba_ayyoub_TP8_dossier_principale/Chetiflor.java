public class Chetiflor extends Pokemon {

    @Override
    public String getEspece() {
        return "Chétiflor";
    }

    public Chetiflor(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(69,"Chétiflor","Chétiflor","plante","poison",75,35,40,50  );
    }

    public static void main(String[] args) {
        Chetiflor Chetiflor = new Chetiflor(69, "plante", "poison", 75, 35, 50);
        System.out.println(Chetiflor);
    }
}
