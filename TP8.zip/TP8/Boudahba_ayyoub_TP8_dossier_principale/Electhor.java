public class Electhor extends Pokemon {

    @Override
    public String getEspece() {
        return "Électhor";
    }

    public Electhor(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(145,"Électhor","Électhor","electrik","vol",90,85,100,90  );
    }

    public static void main(String[] args) {
        Electhor Electhor = new Electhor(145, "electrik", "vol", 90, 85, 90);
        System.out.println(Electhor);
    }
}
