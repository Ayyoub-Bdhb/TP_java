public class Magicarpe extends Pokemon {

    @Override
    public String getEspece() {
        return "Magicarpe";
    }

    public Magicarpe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(129,"Magicarpe","Magicarpe","eau","",10,55,80,20  );
    }

    public static void main(String[] args) {
        Magicarpe Magicarpe = new Magicarpe(129, "eau", "", 10, 55, 20);
        System.out.println(Magicarpe);
    }
}
