public class Mewtwo extends Pokemon {

    @Override
    public String getEspece() {
        return "Mewtwo";
    }

    public Mewtwo(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(150,"Mewtwo","Mewtwo","psy","",110,90,130,106  );
    }

    public static void main(String[] args) {
        Mewtwo Mewtwo = new Mewtwo(150, "psy", "", 110, 90, 106);
        System.out.println(Mewtwo);
    }
}
