public class Roucoups extends Pokemon {

    @Override
    public String getEspece() {
        return "Roucoups";
    }

    public Roucoups(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(17,"Roucoups","Roucoups","normal","vol",60,55,71,63  );
    }

    public static void main(String[] args) {
        Roucoups Roucoups = new Roucoups(17, "normal", "vol", 60, 55, 63);
        System.out.println(Roucoups);
    }
}
