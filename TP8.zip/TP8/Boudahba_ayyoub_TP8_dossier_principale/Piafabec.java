public class Piafabec extends Pokemon {

    @Override
    public String getEspece() {
        return "Piafabec";
    }

    public Piafabec(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(21,"Piafabec","Piafabec","normal","vol",60,30,70,40  );
    }

    public static void main(String[] args) {
        Piafabec Piafabec = new Piafabec(21, "normal", "vol", 60, 30, 40);
        System.out.println(Piafabec);
    }
}
