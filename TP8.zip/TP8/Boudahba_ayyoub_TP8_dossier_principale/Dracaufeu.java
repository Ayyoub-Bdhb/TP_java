public class Dracaufeu extends Pokemon {

    @Override
    public String getEspece() {
        return "Dracaufeu";
    }

    public Dracaufeu(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(6,"Dracaufeu","Dracaufeu","feu","vol",84,78,100,78  );
    }

    public static void main(String[] args) {
        Dracaufeu Dracaufeu = new Dracaufeu(6, "feu", "vol", 84, 78, 78);
        System.out.println(Dracaufeu);
    }
}
