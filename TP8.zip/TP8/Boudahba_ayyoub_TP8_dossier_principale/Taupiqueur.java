public class Taupiqueur extends Pokemon {

    @Override
    public String getEspece() {
        return "Taupiqueur";
    }

    public Taupiqueur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(50,"Taupiqueur","Taupiqueur","sol","",55,25,95,10  );
    }

    public static void main(String[] args) {
        Taupiqueur Taupiqueur = new Taupiqueur(50, "sol", "", 55, 25, 10);
        System.out.println(Taupiqueur);
    }
}
