public class Reptincel extends Pokemon {

    @Override
    public String getEspece() {
        return "Reptincel";
    }

    public Reptincel(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(5,"Reptincel","Reptincel","feu","",64,58,80,58  );
    }

    public static void main(String[] args) {
        Reptincel Reptincel = new Reptincel(5, "feu", "", 64, 58, 58);
        System.out.println(Reptincel);
    }
}
