public class Ferosinge extends Pokemon {

    @Override
    public String getEspece() {
        return "Férosinge";
    }

    public Ferosinge(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(56,"Férosinge","Férosinge","combat","",80,35,70,40  );
    }

    public static void main(String[] args) {
        Ferosinge Ferosinge = new Ferosinge(56, "combat", "", 80, 35, 40);
        System.out.println(Ferosinge);
    }
}
