public class Magmar extends Pokemon {

    @Override
    public String getEspece() {
        return "Magmar";
    }

    public Magmar(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(126,"Magmar","Magmar","feu","",95,57,93,65  );
    }

    public static void main(String[] args) {
        Magmar Magmar = new Magmar(126, "feu", "", 95, 57, 65);
        System.out.println(Magmar);
    }
}
