public class Boustiflor extends Pokemon {

    @Override
    public String getEspece() {
        return "Boustiflor";
    }

    public Boustiflor(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(70,"Boustiflor","Boustiflor","plante","poison",90,50,55,65  );
    }

    public static void main(String[] args) {
        Boustiflor Boustiflor = new Boustiflor(70, "plante", "poison", 90, 50, 65);
        System.out.println(Boustiflor);
    }
}
