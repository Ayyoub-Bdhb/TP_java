public class Florizarre extends Pokemon {

    @Override
    public String getEspece() {
        return "Florizarre";
    }

    public Florizarre(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(3,"Florizarre","Florizarre","plante","poison",82,83,80,80  );
    }

    public static void main(String[] args) {
        Florizarre Florizarre = new Florizarre(3, "plante", "poison", 82, 83, 80);
        System.out.println(Florizarre);
    }
}
