public class Rondoudou extends Pokemon {

    @Override
    public String getEspece() {
        return "Rondoudou";
    }

    public Rondoudou(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(39,"Rondoudou","Rondoudou","normal","",45,20,20,115  );
    }

    public static void main(String[] args) {
        Rondoudou Rondoudou = new Rondoudou(39, "normal", "", 45, 20, 115);
        System.out.println(Rondoudou);
    }
}
