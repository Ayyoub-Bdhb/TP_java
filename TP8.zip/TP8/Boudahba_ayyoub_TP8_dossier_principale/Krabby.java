public class Krabby extends Pokemon {

    @Override
    public String getEspece() {
        return "Krabby";
    }

    public Krabby(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(98,"Krabby","Krabby","eau","",105,90,50,30  );
    }

    public static void main(String[] args) {
        Krabby Krabby = new Krabby(98, "eau", "", 105, 90, 30);
        System.out.println(Krabby);
    }
}
