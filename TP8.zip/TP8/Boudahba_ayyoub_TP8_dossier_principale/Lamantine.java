public class Lamantine extends Pokemon {

    @Override
    public String getEspece() {
        return "Lamantine";
    }

    public Lamantine(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(87,"Lamantine","Lamantine","eau","glace",70,80,70,90  );
    }

    public static void main(String[] args) {
        Lamantine Lamantine = new Lamantine(87, "eau", "glace", 70, 80, 90);
        System.out.println(Lamantine);
    }
}
