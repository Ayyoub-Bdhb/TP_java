public class Onix extends Pokemon {

    @Override
    public String getEspece() {
        return "Onix";
    }

    public Onix(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(95,"Onix","Onix","roche","sol",45,160,70,35  );
    }

    public static void main(String[] args) {
        Onix Onix = new Onix(95, "roche", "sol", 45, 160, 35);
        System.out.println(Onix);
    }
}
