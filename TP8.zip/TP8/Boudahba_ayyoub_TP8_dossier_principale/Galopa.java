public class Galopa extends Pokemon {

    @Override
    public String getEspece() {
        return "Galopa";
    }

    public Galopa(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(78,"Galopa","Galopa","feu","",100,70,105,65  );
    }

    public static void main(String[] args) {
        Galopa Galopa = new Galopa(78, "feu", "", 100, 70, 65);
        System.out.println(Galopa);
    }
}
