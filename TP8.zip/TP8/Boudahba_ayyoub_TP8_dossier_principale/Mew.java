public class Mew extends Pokemon {

    @Override
    public String getEspece() {
        return "Mew";
    }

    public Mew(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(151,"Mew","Mew","psy","",100,100,100,100  );
    }

    public static void main(String[] args) {
        Mew Mew = new Mew(151, "psy", "", 100, 100, 100);
        System.out.println(Mew);
    }
}
