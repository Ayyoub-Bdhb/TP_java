public class Psykokwak extends Pokemon {

    @Override
    public String getEspece() {
        return "Psykokwak";
    }

    public Psykokwak(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(54,"Psykokwak","Psykokwak","eau","",52,48,55,50  );
    }

    public static void main(String[] args) {
        Psykokwak Psykokwak = new Psykokwak(54, "eau", "", 52, 48, 50);
        System.out.println(Psykokwak);
    }
}
