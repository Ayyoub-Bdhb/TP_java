public class Excelangue extends Pokemon {

    @Override
    public String getEspece() {
        return "Excelangue";
    }

    public Excelangue(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(108,"Excelangue","Excelangue","normal","",55,75,30,90  );
    }

    public static void main(String[] args) {
        Excelangue Excelangue = new Excelangue(108, "normal", "", 55, 75, 90);
        System.out.println(Excelangue);
    }
}
