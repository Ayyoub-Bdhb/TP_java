public class Minidraco extends Pokemon {

    @Override
    public String getEspece() {
        return "Minidraco";
    }

    public Minidraco(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(147,"Minidraco","Minidraco","dragon","",64,45,50,41  );
    }

    public static void main(String[] args) {
        Minidraco Minidraco = new Minidraco(147, "dragon", "", 64, 45, 41);
        System.out.println(Minidraco);
    }
}
