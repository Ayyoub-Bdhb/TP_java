public class Arbok extends Pokemon {

    @Override
    public String getEspece() {
        return "Arbok";
    }

    public Arbok(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(24,"Arbok","Arbok","poison","",85,69,80,60  );
    }

    public static void main(String[] args) {
        Arbok Arbok = new Arbok(24, "poison", "", 85, 69, 60);
        System.out.println(Arbok);
    }
}
