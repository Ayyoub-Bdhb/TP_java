public class Nidoking extends Pokemon {

    @Override
    public String getEspece() {
        return "Nidoking";
    }

    public Nidoking(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(34,"Nidoking","Nidoking","poison","sol",92,77,85,81  );
    }

    public static void main(String[] args) {
        Nidoking Nidoking = new Nidoking(34, "poison", "sol", 92, 77, 81);
        System.out.println(Nidoking);
    }
}
