public class Caninos extends Pokemon {

    @Override
    public String getEspece() {
        return "Caninos";
    }

    public Caninos(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(58,"Caninos","Caninos","feu","",70,45,60,55  );
    }

    public static void main(String[] args) {
        Caninos Caninos = new Caninos(58, "feu", "", 70, 45, 55);
        System.out.println(Caninos);
    }
}
