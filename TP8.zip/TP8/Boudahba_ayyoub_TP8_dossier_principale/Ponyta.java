public class Ponyta extends Pokemon {

    @Override
    public String getEspece() {
        return "Ponyta";
    }

    public Ponyta(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(77,"Ponyta","Ponyta","feu","",85,55,90,50  );
    }

    public static void main(String[] args) {
        Ponyta Ponyta = new Ponyta(77, "feu", "", 85, 55, 50);
        System.out.println(Ponyta);
    }
}
