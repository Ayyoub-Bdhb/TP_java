public class Spectrum extends Pokemon {

    @Override
    public String getEspece() {
        return "Spectrum";
    }

    public Spectrum(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(93,"Spectrum","Spectrum","spectre","poison",50,45,95,45  );
    }

    public static void main(String[] args) {
        Spectrum Spectrum = new Spectrum(93, "spectre", "poison", 50, 45, 45);
        System.out.println(Spectrum);
    }
}
