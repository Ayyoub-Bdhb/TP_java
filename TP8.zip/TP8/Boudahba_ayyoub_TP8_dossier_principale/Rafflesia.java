public class Rafflesia extends Pokemon {

    @Override
    public String getEspece() {
        return "Rafflesia";
    }

    public Rafflesia(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(45,"Rafflesia","Rafflesia","plante","poison",80,85,50,75  );
    }

    public static void main(String[] args) {
        Rafflesia Rafflesia = new Rafflesia(45, "plante", "poison", 80, 85, 75);
        System.out.println(Rafflesia);
    }
}
