public class Arcanin extends Pokemon {

    @Override
    public String getEspece() {
        return "Arcanin";
    }

    public Arcanin(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(59,"Arcanin","Arcanin","feu","",110,80,95,90  );
    }

    public static void main(String[] args) {
        Arcanin Arcanin = new Arcanin(59, "feu", "", 110, 80, 90);
        System.out.println(Arcanin);
    }
}
