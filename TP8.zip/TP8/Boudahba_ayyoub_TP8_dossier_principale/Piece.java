public class Piece{
    private Pokemon un_Pokemon;
    private int joueur;
    private Position position;



    public Piece(){
        this.un_Pokemon = new Pikachu(25, "electrik", "", 55, 30, 35); 
        this.joueur = 1;
        this.position = new Position("A",1);
    }



    public Piece(Piece p){
        this.un_Pokemon = p.un_Pokemon;
        this.joueur = p.joueur;
        this.position = p.position;
    }

    public Piece(Pokemon un_Pokemon, int joueur, int x , int y){ 
        this.position = new Position(x , y );
        this.un_Pokemon = un_Pokemon;
        this.joueur = joueur;
    }

    public Piece(Pokemon un_Pokemon , int joueur , Position pos ){
        this.un_Pokemon = un_Pokemon; 
        this.joueur = joueur;
        this.position = pos;
    }

    public Piece(Pokemon un_Pokemon , int numjoueur , char x , int y ){
        this.un_Pokemon = un_Pokemon;
        this.joueur = numjoueur;
        this.position = new Position(x , y);
    }



    public Pokemon getUn_Pokemon() {
        return this.un_Pokemon;
    }


    public void setUn_Pokemon(Pokemon un_Pokemon) {
        this.un_Pokemon = un_Pokemon;
    }
    public int getJoueur() {
        return this.joueur;
    }
    public void setJoueur(int joueur) {
        this.joueur = joueur;
    }
    public Position getPosition() {
        return this.position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }



    public boolean equals(Object o) {
        if (!(o instanceof Piece)) {
            return false;
        }
        Piece p = (Piece) o;
        return this.un_Pokemon.equals(p.un_Pokemon) &&
                this.joueur == p.joueur &&
                this.position.equals(p.position);
    }

    public String toString() {
        return this.un_Pokemon.getEspece() + " du " + "joueur " + this.joueur + " en " + this.position; 
    }
    public static void main(String[] args) {
        Piece p1 = new Piece();
        System.out.println(p1);

}

}