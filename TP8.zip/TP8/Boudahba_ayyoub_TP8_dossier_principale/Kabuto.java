public class Kabuto extends Pokemon {

    @Override
    public String getEspece() {
        return "Kabuto";
    }

    public Kabuto(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(140,"Kabuto","Kabuto","roche","eau",80,90,55,30  );
    }

    public static void main(String[] args) {
        Kabuto Kabuto = new Kabuto(140, "roche", "eau", 80, 90, 30);
        System.out.println(Kabuto);
    }
}
