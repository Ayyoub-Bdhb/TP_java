public class NidoranF extends Pokemon {

    @Override
    public String getEspece() {
        return "Nidoran♀";
    }

    public NidoranF(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(29,"Nidoran♀","Nidoran♀","poison","",47,52,41,55  );
    }

    public static void main(String[] args) {
        NidoranF NidoranF = new NidoranF(29, "poison", "", 47, 52, 55);
        System.out.println(NidoranF);
    }
}
