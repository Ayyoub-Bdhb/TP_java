public class Melodelfe extends Pokemon {

    @Override
    public String getEspece() {
        return "Mélodelfe";
    }

    public Melodelfe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(36,"Mélodelfe","Mélodelfe","normal","",70,73,60,95  );
    }

    public static void main(String[] args) {
        Melodelfe Melodelfe = new Melodelfe(36, "normal", "", 70, 73, 95);
        System.out.println(Melodelfe);
    }
}
