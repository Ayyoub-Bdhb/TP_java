public class Mackogneur extends Pokemon {

    @Override
    public String getEspece() {
        return "Mackogneur";
    }

    public Mackogneur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(68,"Mackogneur","Mackogneur","combat","",130,80,55,90  );
    }

    public static void main(String[] args) {
        Mackogneur Mackogneur = new Mackogneur(68, "combat", "", 130, 80, 90);
        System.out.println(Mackogneur);
    }
}
