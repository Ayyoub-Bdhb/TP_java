public class Magneton extends Pokemon {

    @Override
    public String getEspece() {
        return "Magnéton";
    }

    public Magneton(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(82,"Magnéton","Magnéton","electrik","",60,95,70,50  );
    }

    public static void main(String[] args) {
        Magneton Magneton = new Magneton(82, "electrik", "", 60, 95, 50);
        System.out.println(Magneton);
    }
}
