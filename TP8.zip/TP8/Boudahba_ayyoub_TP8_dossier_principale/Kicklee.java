public class Kicklee extends Pokemon {

    @Override
    public String getEspece() {
        return "Kicklee";
    }

    public Kicklee(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(106,"Kicklee","Kicklee","combat","",120,53,87,50  );
    }

    public static void main(String[] args) {
        Kicklee Kicklee = new Kicklee(106, "combat", "", 120, 53, 50);
        System.out.println(Kicklee);
    }
}
