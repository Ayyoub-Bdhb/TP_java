public class Poissoroy extends Pokemon {

    @Override
    public String getEspece() {
        return "Poissoroy";
    }

    public Poissoroy(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(119,"Poissoroy","Poissoroy","eau","",92,65,68,80  );
    }

    public static void main(String[] args) {
        Poissoroy Poissoroy = new Poissoroy(119, "eau", "", 92, 65, 80);
        System.out.println(Poissoroy);
    }
}
