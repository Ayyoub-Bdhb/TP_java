public class Evoli extends Pokemon {

    @Override
    public String getEspece() {
        return "Évoli";
    }

    public Evoli(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(133,"Évoli","Évoli","normal","",55,50,55,55  );
    }

    public static void main(String[] args) {
        Evoli Evoli = new Evoli(133, "normal", "", 55, 50, 55);
        System.out.println(Evoli);
    }
}
