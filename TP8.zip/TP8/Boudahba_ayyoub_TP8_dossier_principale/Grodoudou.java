public class Grodoudou extends Pokemon {

    @Override
    public String getEspece() {
        return "Grodoudou";
    }

    public Grodoudou(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(40,"Grodoudou","Grodoudou","normal","",70,45,45,140  );
    }

    public static void main(String[] args) {
        Grodoudou Grodoudou = new Grodoudou(40, "normal", "", 70, 45, 140);
        System.out.println(Grodoudou);
    }
}
