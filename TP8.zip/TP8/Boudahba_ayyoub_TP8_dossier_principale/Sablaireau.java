public class Sablaireau extends Pokemon {

    @Override
    public String getEspece() {
        return "Sablaireau";
    }

    public Sablaireau(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(28,"Sablaireau","Sablaireau","sol","",100,110,65,75  );
    }

    public static void main(String[] args) {
        Sablaireau Sablaireau = new Sablaireau(28, "sol", "", 100, 110, 75);
        System.out.println(Sablaireau);
    }
}
