public class Hypocean extends Pokemon {

    @Override
    public String getEspece() {
        return "Hypocéan";
    }

    public Hypocean(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(117,"Hypocéan","Hypocéan","eau","",65,95,85,55  );
    }

    public static void main(String[] args) {
        Hypocean Hypocean = new Hypocean(117, "eau", "", 65, 95, 55);
        System.out.println(Hypocean);
    }
}
