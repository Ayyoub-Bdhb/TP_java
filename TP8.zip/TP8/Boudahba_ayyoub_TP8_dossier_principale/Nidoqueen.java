public class Nidoqueen extends Pokemon {

    @Override
    public String getEspece() {
        return "Nidoqueen";
    }

    public Nidoqueen(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(31,"Nidoqueen","Nidoqueen","poison","sol",82,87,76,90  );
    }

    public static void main(String[] args) {
        Nidoqueen Nidoqueen = new Nidoqueen(31, "poison", "sol", 82, 87, 90);
        System.out.println(Nidoqueen);
    }
}
