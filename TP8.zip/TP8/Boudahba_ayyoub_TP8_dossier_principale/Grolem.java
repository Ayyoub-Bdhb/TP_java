public class Grolem extends Pokemon {

    @Override
    public String getEspece() {
        return "Grolem";
    }

    public Grolem(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(76,"Grolem","Grolem","roche","sol",110,130,45,80  );
    }

    public static void main(String[] args) {
        Grolem Grolem = new Grolem(76, "roche", "sol", 110, 130, 80);
        System.out.println(Grolem);
    }
}
