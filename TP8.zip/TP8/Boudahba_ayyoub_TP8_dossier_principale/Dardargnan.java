public class Dardargnan extends Pokemon {

    @Override
    public String getEspece() {
        return "Dardargnan";
    }

    public Dardargnan(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(15,"Dardargnan","Dardargnan","insecte","poison",80,40,75,65  );
    }

    public static void main(String[] args) {
        Dardargnan Dardargnan = new Dardargnan(15, "insecte", "poison", 80, 40, 65);
        System.out.println(Dardargnan);
    }
}
