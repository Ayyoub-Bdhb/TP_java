public class Tortank extends Pokemon {

    @Override
    public String getEspece() {
        return "Tortank";
    }

    public Tortank(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(9,"Tortank","Tortank","eau","",83,100,78,79  );
    }

    public static void main(String[] args) {
        Tortank Tortank = new Tortank(9, "eau", "", 83, 100, 79);
        System.out.println(Tortank);
    }
}
