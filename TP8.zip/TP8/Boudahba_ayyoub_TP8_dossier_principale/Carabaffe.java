public class Carabaffe extends Pokemon {

    @Override
    public String getEspece() {
        return "Carabaffe";
    }

    public Carabaffe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(8,"Carabaffe","Carabaffe","eau","",63,80,58,59  );
    }

    public static void main(String[] args) {
        Carabaffe Carabaffe = new Carabaffe(8, "eau", "", 63, 80, 59);
        System.out.println(Carabaffe);
    }
}
