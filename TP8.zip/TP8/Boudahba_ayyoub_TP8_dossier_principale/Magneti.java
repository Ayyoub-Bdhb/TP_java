public class Magneti extends Pokemon {

    @Override
    public String getEspece() {
        return "Magnéti";
    }

    public Magneti(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(81,"Magnéti","Magnéti","electrik","",35,70,45,25  );
    }

    public static void main(String[] args) {
        Magneti Magneti = new Magneti(81, "electrik", "", 35, 70, 25);
        System.out.println(Magneti);
    }
}
