public class Leviator extends Pokemon {

    @Override
    public String getEspece() {
        return "Léviator";
    }

    public Leviator(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(130,"Léviator","Léviator","eau","vol",125,79,81,95  );
    }

    public static void main(String[] args) {
        Leviator Leviator = new Leviator(130, "eau", "vol", 125, 79, 95);
        System.out.println(Leviator);
    }
}
