public class Ptera extends Pokemon {

    @Override
    public String getEspece() {
        return "Ptéra";
    }

    public Ptera(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(142,"Ptéra","Ptéra","roche","vol",105,65,130,80  );
    }

    public static void main(String[] args) {
        Ptera Ptera = new Ptera(142, "roche", "vol", 105, 65, 80);
        System.out.println(Ptera);
    }
}
