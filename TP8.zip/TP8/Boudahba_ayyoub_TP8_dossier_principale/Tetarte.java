public class Tetarte extends Pokemon {

    @Override
    public String getEspece() {
        return "Têtarte";
    }

    public Tetarte(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(61,"Têtarte","Têtarte","eau","",65,65,90,65  );
    }

    public static void main(String[] args) {
        Tetarte Tetarte = new Tetarte(61, "eau", "", 65, 65, 65);
        System.out.println(Tetarte);
    }
}
