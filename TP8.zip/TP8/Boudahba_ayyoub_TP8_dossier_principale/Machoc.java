public class Machoc extends Pokemon {

    @Override
    public String getEspece() {
        return "Machoc";
    }

    public Machoc(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(66,"Machoc","Machoc","combat","",80,50,35,70  );
    }

    public static void main(String[] args) {
        Machoc Machoc = new Machoc(66, "combat", "", 80, 50, 70);
        System.out.println(Machoc);
    }
}
