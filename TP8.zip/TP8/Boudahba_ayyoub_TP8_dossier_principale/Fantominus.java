public class Fantominus extends Pokemon {

    @Override
    public String getEspece() {
        return "Fantominus";
    }

    public Fantominus(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(92,"Fantominus","Fantominus","spectre","poison",35,30,80,30  );
    }

    public static void main(String[] args) {
        Fantominus Fantominus = new Fantominus(92, "spectre", "poison", 35, 30, 30);
        System.out.println(Fantominus);
    }
}
