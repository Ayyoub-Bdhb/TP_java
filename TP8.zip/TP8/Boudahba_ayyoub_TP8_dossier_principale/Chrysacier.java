public class Chrysacier extends Pokemon {

    @Override
    public String getEspece() {
        return "Chrysacier";
    }

    public Chrysacier(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(11,"Chrysacier","Chrysacier","insecte","",20,55,30,50  );
    }

    public static void main(String[] args) {
        Chrysacier Chrysacier = new Chrysacier(11, "insecte", "", 20, 55, 50);
        System.out.println(Chrysacier);
    }
}
