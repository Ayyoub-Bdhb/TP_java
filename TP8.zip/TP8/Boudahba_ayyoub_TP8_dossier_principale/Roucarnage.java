public class Roucarnage extends Pokemon {

    @Override
    public String getEspece() {
        return "Roucarnage";
    }

    public Roucarnage(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(18,"Roucarnage","Roucarnage","normal","vol",80,75,91,83  );
    }

    public static void main(String[] args) {
        Roucarnage Roucarnage = new Roucarnage(18, "normal", "vol", 80, 75, 83);
        System.out.println(Roucarnage);
    }
}
