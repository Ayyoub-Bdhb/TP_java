public class Ronflex extends Pokemon {

    @Override
    public String getEspece() {
        return "Ronflex";
    }

    public Ronflex(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(143,"Ronflex","Ronflex","normal","",110,65,30,160  );
    }

    public static void main(String[] args) {
        Ronflex Ronflex = new Ronflex(143, "normal", "", 110, 65, 160);
        System.out.println(Ronflex);
    }
}
