public class Porygon extends Pokemon {

    @Override
    public String getEspece() {
        return "Porygon";
    }

    public Porygon(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(137,"Porygon","Porygon","normal","",60,70,40,65  );
    }

    public static void main(String[] args) {
        Porygon Porygon = new Porygon(137, "normal", "", 60, 70, 65);
        System.out.println(Porygon);
    }
}
