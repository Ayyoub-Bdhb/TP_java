public class Voltali extends Pokemon {

    @Override
    public String getEspece() {
        return "Voltali";
    }

    public Voltali(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(135,"Voltali","Voltali","electrik","",65,60,130,65  );
    }

    public static void main(String[] args) {
        Voltali Voltali = new Voltali(135, "electrik", "", 65, 60, 65);
        System.out.println(Voltali);
    }
}
