public class Rapasdepic extends Pokemon {

    @Override
    public String getEspece() {
        return "Rapasdepic";
    }

    public Rapasdepic(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(22,"Rapasdepic","Rapasdepic","normal","vol",90,65,100,65  );
    }

    public static void main(String[] args) {
        Rapasdepic Rapasdepic = new Rapasdepic(22, "normal", "vol", 90, 65, 65);
        System.out.println(Rapasdepic);
    }
}
