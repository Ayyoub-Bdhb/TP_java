public class Krabboss extends Pokemon {

    @Override
    public String getEspece() {
        return "Krabboss";
    }

    public Krabboss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(99,"Krabboss","Krabboss","eau","",130,115,75,55  );
    }

    public static void main(String[] args) {
        Krabboss Krabboss = new Krabboss(99, "eau", "", 130, 115, 55);
        System.out.println(Krabboss);
    }
}
