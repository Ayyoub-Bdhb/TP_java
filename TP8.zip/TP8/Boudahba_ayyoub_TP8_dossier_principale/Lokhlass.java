public class Lokhlass extends Pokemon {

    @Override
    public String getEspece() {
        return "Lokhlass";
    }

    public Lokhlass(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(131,"Lokhlass","Lokhlass","eau","glace",85,80,60,130  );
    }

    public static void main(String[] args) {
        Lokhlass Lokhlass = new Lokhlass(131, "eau", "glace", 85, 80, 130);
        System.out.println(Lokhlass);
    }
}
