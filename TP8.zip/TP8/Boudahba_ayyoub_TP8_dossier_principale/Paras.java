public class Paras extends Pokemon {

    @Override
    public String getEspece() {
        return "Paras";
    }

    public Paras(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(46,"Paras","Paras","insecte","plante",70,55,25,35  );
    }

    public static void main(String[] args) {
        Paras Paras = new Paras(46, "insecte", "plante", 70, 55, 35);
        System.out.println(Paras);
    }
}
