public class Chenipan extends Pokemon {

    @Override
    public String getEspece() {
        return "Chenipan";
    }

    public Chenipan(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(10,"Chenipan","Chenipan","insecte","",30,35,45,45  );
    }

    public static void main(String[] args) {
        Chenipan Chenipan = new Chenipan(10, "insecte", "", 30, 35, 45);
        System.out.println(Chenipan);
    }
}
