public class Galopa extends Pokemon {

    public String getEspece() {
        return "Galopa";
    }

    public Galopa(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Galopa", "feu", "", attPokemon, defPokemon, 105, pvPokemon);
    }

    public static void main(String[] args) {
        Galopa Galopa = new Galopa(78, "feu", "", 100, 70, 65);
        System.out.println(Galopa);
    }
}
