public class Scarabrute extends Pokemon {

    public String getEspece() {
        return "Scarabrute";
    }

    public Scarabrute(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Scarabrute", "insecte", "", attPokemon, defPokemon, 85, pvPokemon);
    }

    public static void main(String[] args) {
        Scarabrute Scarabrute = new Scarabrute(127, "insecte", "", 125, 100, 65);
        System.out.println(Scarabrute);
    }
}
