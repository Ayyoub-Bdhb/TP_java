public class Feunard extends Pokemon {

    public String getEspece() {
        return "Feunard";
    }

    public Feunard(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Feunard", "feu", "", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Feunard Feunard = new Feunard(38, "feu", "", 76, 75, 73);
        System.out.println(Feunard);
    }
}
