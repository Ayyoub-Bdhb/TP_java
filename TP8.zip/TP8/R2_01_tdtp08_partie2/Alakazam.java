public class Alakazam extends Pokemon {

    public String getEspece() {
        return "Alakazam";
    }

    public Alakazam(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Alakazam", "psy", "", attPokemon, defPokemon, 120, pvPokemon);
    }

    public static void main(String[] args) {
        Alakazam Alakazam = new Alakazam(65, "psy", "", 50, 45, 55);
        System.out.println(Alakazam);
    }
}
