public class Nosferalto extends Pokemon {

    public String getEspece() {
        return "Nosferalto";
    }

    public Nosferalto(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nosferalto", "poison", "vol", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Nosferalto Nosferalto = new Nosferalto(42, "poison", "vol", 80, 70, 75);
        System.out.println(Nosferalto);
    }
}
