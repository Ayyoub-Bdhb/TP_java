public class Rhinocorne extends Pokemon {

    public String getEspece() {
        return "Rhinocorne";
    }

    public Rhinocorne(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Rhinocorne", "sol", "roche", attPokemon, defPokemon, 25, pvPokemon);
    }

    public static void main(String[] args) {
        Rhinocorne Rhinocorne = new Rhinocorne(111, "sol", "roche", 85, 95, 80);
        System.out.println(Rhinocorne);
    }
}
