public class Amonistar extends Pokemon {

    public String getEspece() {
        return "Amonistar";
    }

    public Amonistar(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Amonistar", "roche", "eau", attPokemon, defPokemon, 55, pvPokemon);
    }

    public static void main(String[] args) {
        Amonistar Amonistar = new Amonistar(139, "roche", "eau", 60, 125, 70);
        System.out.println(Amonistar);
    }
}
