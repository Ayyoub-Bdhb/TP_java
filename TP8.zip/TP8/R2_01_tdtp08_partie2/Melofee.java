public class Melofee extends Pokemon {

    public String getEspece() {
        return "Mélofée";
    }

    public Melofee(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Mélofée", "normal", "", attPokemon, defPokemon, 35, pvPokemon);
    }

    public static void main(String[] args) {
        Melofee Melofee = new Melofee(35, "normal", "", 45, 48, 70);
        System.out.println(Melofee);
    }
}
