public class Gravalanch extends Pokemon {

    public String getEspece() {
        return "Gravalanch";
    }

    public Gravalanch(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Gravalanch", "roche", "sol", attPokemon, defPokemon, 35, pvPokemon);
    }

    public static void main(String[] args) {
        Gravalanch Gravalanch = new Gravalanch(75, "roche", "sol", 95, 115, 55);
        System.out.println(Gravalanch);
    }
}
