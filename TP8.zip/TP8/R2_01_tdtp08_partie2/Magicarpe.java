public class Magicarpe extends Pokemon {

    public String getEspece() {
        return "Magicarpe";
    }

    public Magicarpe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Magicarpe", "eau", "", attPokemon, defPokemon, 80, pvPokemon);
    }

    public static void main(String[] args) {
        Magicarpe Magicarpe = new Magicarpe(129, "eau", "", 10, 55, 20);
        System.out.println(Magicarpe);
    }
}
