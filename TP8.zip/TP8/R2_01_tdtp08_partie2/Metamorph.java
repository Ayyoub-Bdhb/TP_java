public class Metamorph extends Pokemon {

    public String getEspece() {
        return "Métamorph";
    }

    public Metamorph(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Métamorph", "normal", "", attPokemon, defPokemon, 48, pvPokemon);
    }

    public static void main(String[] args) {
        Metamorph Metamorph = new Metamorph(132, "normal", "", 48, 48, 48);
        System.out.println(Metamorph);
    }
}
