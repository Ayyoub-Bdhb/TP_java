public class Akwakwak extends Pokemon {

    public String getEspece() {
        return "Akwakwak";
    }

    public Akwakwak(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Akwakwak", "eau", "", attPokemon, defPokemon, 85, pvPokemon);
    }

    public static void main(String[] args) {
        Akwakwak Akwakwak = new Akwakwak(55, "eau", "", 82, 78, 80);
        System.out.println(Akwakwak);
    }
}
