public class Onix extends Pokemon {

    public String getEspece() {
        return "Onix";
    }

    public Onix(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Onix", "roche", "sol", attPokemon, defPokemon, 70, pvPokemon);
    }

    public static void main(String[] args) {
        Onix Onix = new Onix(95, "roche", "sol", 45, 160, 35);
        System.out.println(Onix);
    }
}
