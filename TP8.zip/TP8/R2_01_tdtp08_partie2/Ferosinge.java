public class Ferosinge extends Pokemon {

    public String getEspece() {
        return "Férosinge";
    }

    public Ferosinge(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Férosinge", "combat", "", attPokemon, defPokemon, 70, pvPokemon);
    }

    public static void main(String[] args) {
        Ferosinge Ferosinge = new Ferosinge(56, "combat", "", 80, 35, 40);
        System.out.println(Ferosinge);
    }
}
