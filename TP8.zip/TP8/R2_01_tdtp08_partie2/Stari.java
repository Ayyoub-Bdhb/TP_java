public class Stari extends Pokemon {

    public String getEspece() {
        return "Stari";
    }

    public Stari(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Stari", "eau", "", attPokemon, defPokemon, 85, pvPokemon);
    }

    public static void main(String[] args) {
        Stari Stari = new Stari(120, "eau", "", 45, 55, 30);
        System.out.println(Stari);
    }
}
