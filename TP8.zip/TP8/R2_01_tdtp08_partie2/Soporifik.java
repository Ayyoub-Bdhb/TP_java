public class Soporifik extends Pokemon {

    public String getEspece() {
        return "Soporifik";
    }

    public Soporifik(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Soporifik", "psy", "", attPokemon, defPokemon, 42, pvPokemon);
    }

    public static void main(String[] args) {
        Soporifik Soporifik = new Soporifik(96, "psy", "", 48, 45, 60);
        System.out.println(Soporifik);
    }
}
