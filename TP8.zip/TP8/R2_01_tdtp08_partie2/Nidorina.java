public class Nidorina extends Pokemon {

    public String getEspece() {
        return "Nidorina";
    }

    public Nidorina(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nidorina", "poison", "", attPokemon, defPokemon, 56, pvPokemon);
    }

    public static void main(String[] args) {
        Nidorina Nidorina = new Nidorina(30, "poison", "", 62, 67, 70);
        System.out.println(Nidorina);
    }
}
