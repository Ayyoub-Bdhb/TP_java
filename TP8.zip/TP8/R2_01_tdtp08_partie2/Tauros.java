public class Tauros extends Pokemon {

    public String getEspece() {
        return "Tauros";
    }

    public Tauros(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Tauros", "normal", "", attPokemon, defPokemon, 110, pvPokemon);
    }

    public static void main(String[] args) {
        Tauros Tauros = new Tauros(128, "normal", "", 100, 95, 75);
        System.out.println(Tauros);
    }
}
