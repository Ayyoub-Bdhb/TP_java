public class Hypocean extends Pokemon {

    public String getEspece() {
        return "Hypocéan";
    }

    public Hypocean(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Hypocéan", "eau", "", attPokemon, defPokemon, 85, pvPokemon);
    }

    public static void main(String[] args) {
        Hypocean Hypocean = new Hypocean(117, "eau", "", 65, 95, 55);
        System.out.println(Hypocean);
    }
}
