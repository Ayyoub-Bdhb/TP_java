public class Lippoutou extends Pokemon {

    public String getEspece() {
        return "Lippoutou";
    }

    public Lippoutou(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Lippoutou", "glace", "psy", attPokemon, defPokemon, 95, pvPokemon);
    }

    public static void main(String[] args) {
        Lippoutou Lippoutou = new Lippoutou(124, "glace", "psy", 50, 35, 65);
        System.out.println(Lippoutou);
    }
}
