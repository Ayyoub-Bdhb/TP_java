public class Minidraco extends Pokemon {

    public String getEspece() {
        return "Minidraco";
    }

    public Minidraco(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Minidraco", "dragon", "", attPokemon, defPokemon, 50, pvPokemon);
    }

    public static void main(String[] args) {
        Minidraco Minidraco = new Minidraco(147, "dragon", "", 64, 45, 41);
        System.out.println(Minidraco);
    }
}
