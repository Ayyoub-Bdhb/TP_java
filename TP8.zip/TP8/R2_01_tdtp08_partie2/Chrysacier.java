public class Chrysacier extends Pokemon {

    public String getEspece() {
        return "Chrysacier";
    }

    public Chrysacier(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Chrysacier", "insecte", "", attPokemon, defPokemon, 30, pvPokemon);
    }

    public static void main(String[] args) {
        Chrysacier Chrysacier = new Chrysacier(11, "insecte", "", 20, 55, 50);
        System.out.println(Chrysacier);
    }
}
