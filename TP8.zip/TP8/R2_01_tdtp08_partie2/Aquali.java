public class Aquali extends Pokemon {

    public String getEspece() {
        return "Aquali";
    }

    public Aquali(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Aquali", "eau", "", attPokemon, defPokemon, 65, pvPokemon);
    }

    public static void main(String[] args) {
        Aquali Aquali = new Aquali(134, "eau", "", 65, 60, 130);
        System.out.println(Aquali);
    }
}
