public class Voltali extends Pokemon {

    public String getEspece() {
        return "Voltali";
    }

    public Voltali(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Voltali", "electrik", "", attPokemon, defPokemon, 130, pvPokemon);
    }

    public static void main(String[] args) {
        Voltali Voltali = new Voltali(135, "electrik", "", 65, 60, 65);
        System.out.println(Voltali);
    }
}
