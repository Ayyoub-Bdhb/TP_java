public class Grotadmorv extends Pokemon {

    public String getEspece() {
        return "Grotadmorv";
    }

    public Grotadmorv(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Grotadmorv", "poison", "", attPokemon, defPokemon, 50, pvPokemon);
    }

    public static void main(String[] args) {
        Grotadmorv Grotadmorv = new Grotadmorv(89, "poison", "", 105, 75, 105);
        System.out.println(Grotadmorv);
    }
}
