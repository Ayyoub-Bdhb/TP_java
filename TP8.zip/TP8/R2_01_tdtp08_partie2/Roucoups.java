public class Roucoups extends Pokemon {

    public String getEspece() {
        return "Roucoups";
    }

    public Roucoups(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Roucoups", "normal", "vol", attPokemon, defPokemon, 71, pvPokemon);
    }

    public static void main(String[] args) {
        Roucoups Roucoups = new Roucoups(17, "normal", "vol", 60, 55, 63);
        System.out.println(Roucoups);
    }
}
