public class Draco extends Pokemon {

    public String getEspece() {
        return "Draco";
    }

    public Draco(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Draco", "dragon", "", attPokemon, defPokemon, 70, pvPokemon);
    }

    public static void main(String[] args) {
        Draco Draco = new Draco(148, "dragon", "", 84, 65, 61);
        System.out.println(Draco);
    }
}
