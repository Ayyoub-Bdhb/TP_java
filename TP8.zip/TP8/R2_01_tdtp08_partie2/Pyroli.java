public class Pyroli extends Pokemon {

    public String getEspece() {
        return "Pyroli";
    }

    public Pyroli(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Pyroli", "feu", "", attPokemon, defPokemon, 65, pvPokemon);
    }

    public static void main(String[] args) {
        Pyroli Pyroli = new Pyroli(136, "feu", "", 130, 60, 65);
        System.out.println(Pyroli);
    }
}
