public class Kadabra extends Pokemon {

    public String getEspece() {
        return "Kadabra";
    }

    public Kadabra(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Kadabra", "psy", "", attPokemon, defPokemon, 105, pvPokemon);
    }

    public static void main(String[] args) {
        Kadabra Kadabra = new Kadabra(64, "psy", "", 35, 30, 40);
        System.out.println(Kadabra);
    }
}
