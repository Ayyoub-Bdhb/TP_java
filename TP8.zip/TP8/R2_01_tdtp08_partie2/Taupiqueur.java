public class Taupiqueur extends Pokemon {

    public String getEspece() {
        return "Taupiqueur";
    }

    public Taupiqueur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Taupiqueur", "sol", "", attPokemon, defPokemon, 95, pvPokemon);
    }

    public static void main(String[] args) {
        Taupiqueur Taupiqueur = new Taupiqueur(50, "sol", "", 55, 25, 10);
        System.out.println(Taupiqueur);
    }
}
