public class Otaria extends Pokemon {

    public String getEspece() {
        return "Otaria";
    }

    public Otaria(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Otaria", "eau", "", attPokemon, defPokemon, 45, pvPokemon);
    }

    public static void main(String[] args) {
        Otaria Otaria = new Otaria(86, "eau", "", 45, 55, 65);
        System.out.println(Otaria);
    }
}
