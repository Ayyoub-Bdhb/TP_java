public class Leveinard extends Pokemon {

    public String getEspece() {
        return "Leveinard";
    }

    public Leveinard(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Leveinard", "normal", "", attPokemon, defPokemon, 50, pvPokemon);
    }

    public static void main(String[] args) {
        Leveinard Leveinard = new Leveinard(113, "normal", "", 5, 5, 250);
        System.out.println(Leveinard);
    }
}
