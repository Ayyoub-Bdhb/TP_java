public class Smogogo extends Pokemon {

    public String getEspece() {
        return "Smogogo";
    }

    public Smogogo(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Smogogo", "poison", "", attPokemon, defPokemon, 60, pvPokemon);
    }

    public static void main(String[] args) {
        Smogogo Smogogo = new Smogogo(110, "poison", "", 90, 120, 65);
        System.out.println(Smogogo);
    }
}
