public class Voltorbe extends Pokemon {

    public String getEspece() {
        return "Voltorbe";
    }

    public Voltorbe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Voltorbe", "electrik", "", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Voltorbe Voltorbe = new Voltorbe(100, "electrik", "", 30, 50, 40);
        System.out.println(Voltorbe);
    }
}
