public class Colossinge extends Pokemon {

    public String getEspece() {
        return "Colossinge";
    }

    public Colossinge(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Colossinge", "combat", "", attPokemon, defPokemon, 95, pvPokemon);
    }

    public static void main(String[] args) {
        Colossinge Colossinge = new Colossinge(57, "combat", "", 105, 60, 65);
        System.out.println(Colossinge);
    }
}
