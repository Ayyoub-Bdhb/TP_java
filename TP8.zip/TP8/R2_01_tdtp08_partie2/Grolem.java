public class Grolem extends Pokemon {

    public String getEspece() {
        return "Grolem";
    }

    public Grolem(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Grolem", "roche", "sol", attPokemon, defPokemon, 45, pvPokemon);
    }

    public static void main(String[] args) {
        Grolem Grolem = new Grolem(76, "roche", "sol", 110, 130, 80);
        System.out.println(Grolem);
    }
}
