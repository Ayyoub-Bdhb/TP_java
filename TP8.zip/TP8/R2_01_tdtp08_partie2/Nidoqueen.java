public class Nidoqueen extends Pokemon {

    public String getEspece() {
        return "Nidoqueen";
    }

    public Nidoqueen(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nidoqueen", "poison", "sol", attPokemon, defPokemon, 76, pvPokemon);
    }

    public static void main(String[] args) {
        Nidoqueen Nidoqueen = new Nidoqueen(31, "poison", "sol", 82, 87, 90);
        System.out.println(Nidoqueen);
    }
}
