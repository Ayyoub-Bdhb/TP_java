public class Mackogneur extends Pokemon {

    public String getEspece() {
        return "Mackogneur";
    }

    public Mackogneur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Mackogneur", "combat", "", attPokemon, defPokemon, 55, pvPokemon);
    }

    public static void main(String[] args) {
        Mackogneur Mackogneur = new Mackogneur(68, "combat", "", 130, 80, 90);
        System.out.println(Mackogneur);
    }
}
