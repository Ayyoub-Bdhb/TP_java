public class Herbizarre extends Pokemon {

    public String getEspece() {
        return "Herbizarre";
    }

    public Herbizarre(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Herbizarre", "plante", "poison", attPokemon, defPokemon, 60, pvPokemon);
    }

    public static void main(String[] args) {
        Herbizarre Herbizarre = new Herbizarre(2, "plante", "poison", 62, 63, 60);
        System.out.println(Herbizarre);
    }
}
