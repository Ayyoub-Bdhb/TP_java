public class Tygnon extends Pokemon {

    public String getEspece() {
        return "Tygnon";
    }

    public Tygnon(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Tygnon", "combat", "", attPokemon, defPokemon, 76, pvPokemon);
    }

    public static void main(String[] args) {
        Tygnon Tygnon = new Tygnon(107, "combat", "", 105, 79, 50);
        System.out.println(Tygnon);
    }
}
