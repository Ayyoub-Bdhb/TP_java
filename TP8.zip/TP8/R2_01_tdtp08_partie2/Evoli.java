public class Evoli extends Pokemon {

    public String getEspece() {
        return "Évoli";
    }

    public Evoli(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Évoli", "normal", "", attPokemon, defPokemon, 55, pvPokemon);
    }

    public static void main(String[] args) {
        Evoli Evoli = new Evoli(133, "normal", "", 55, 50, 55);
        System.out.println(Evoli);
    }
}
