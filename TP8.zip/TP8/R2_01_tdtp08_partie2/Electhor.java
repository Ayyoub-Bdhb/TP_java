public class Electhor extends Pokemon {

    public String getEspece() {
        return "Électhor";
    }

    public Electhor(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Électhor", "electrik", "vol", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Electhor Electhor = new Electhor(145, "electrik", "vol", 90, 85, 90);
        System.out.println(Electhor);
    }
}
