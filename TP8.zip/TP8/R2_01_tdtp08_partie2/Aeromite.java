public class Aeromite extends Pokemon {

    public String getEspece() {
        return "Aéromite";
    }

    public Aeromite(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Aéromite", "insecte", "poison", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Aeromite Aeromite = new Aeromite(49, "insecte", "poison", 65, 60, 70);
        System.out.println(Aeromite);
    }
}
