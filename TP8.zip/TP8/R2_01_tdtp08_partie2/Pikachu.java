public class Pikachu extends Pokemon {

    public String getEspece() {
        return "Pikachu";
    }

    public Pikachu(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Pikachu", "electrik", "", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Pikachu Pikachu = new Pikachu(25, "electrik", "", 55, 30, 35);
        System.out.println(Pikachu);
    }
}
