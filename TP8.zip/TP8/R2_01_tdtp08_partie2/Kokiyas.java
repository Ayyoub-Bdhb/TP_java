public class Kokiyas extends Pokemon {

    public String getEspece() {
        return "Kokiyas";
    }

    public Kokiyas(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Kokiyas", "eau", "", attPokemon, defPokemon, 40, pvPokemon);
    }

    public static void main(String[] args) {
        Kokiyas Kokiyas = new Kokiyas(90, "eau", "", 65, 100, 30);
        System.out.println(Kokiyas);
    }
}
