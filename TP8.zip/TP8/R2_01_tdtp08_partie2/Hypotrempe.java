public class Hypotrempe extends Pokemon {

    public String getEspece() {
        return "Hypotrempe";
    }

    public Hypotrempe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Hypotrempe", "eau", "", attPokemon, defPokemon, 60, pvPokemon);
    }

    public static void main(String[] args) {
        Hypotrempe Hypotrempe = new Hypotrempe(116, "eau", "", 40, 70, 30);
        System.out.println(Hypotrempe);
    }
}
