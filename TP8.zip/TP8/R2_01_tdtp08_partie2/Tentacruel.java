public class Tentacruel extends Pokemon {

    public String getEspece() {
        return "Tentacruel";
    }

    public Tentacruel(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Tentacruel", "eau", "poison", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Tentacruel Tentacruel = new Tentacruel(73, "eau", "poison", 70, 65, 80);
        System.out.println(Tentacruel);
    }
}
