public class Flagadoss extends Pokemon {

    public String getEspece() {
        return "Flagadoss";
    }

    public Flagadoss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Flagadoss", "eau", "psy", attPokemon, defPokemon, 30, pvPokemon);
    }

    public static void main(String[] args) {
        Flagadoss Flagadoss = new Flagadoss(80, "eau", "psy", 75, 110, 95);
        System.out.println(Flagadoss);
    }
}
