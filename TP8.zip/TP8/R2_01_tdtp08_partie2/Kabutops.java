public class Kabutops extends Pokemon {

    public String getEspece() {
        return "Kabutops";
    }

    public Kabutops(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Kabutops", "roche", "eau", attPokemon, defPokemon, 80, pvPokemon);
    }

    public static void main(String[] args) {
        Kabutops Kabutops = new Kabutops(141, "roche", "eau", 115, 105, 60);
        System.out.println(Kabutops);
    }
}
