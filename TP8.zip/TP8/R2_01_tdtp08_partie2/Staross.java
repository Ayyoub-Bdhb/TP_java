public class Staross extends Pokemon {

    public String getEspece() {
        return "Staross";
    }

    public Staross(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Staross", "eau", "psy", attPokemon, defPokemon, 115, pvPokemon);
    }

    public static void main(String[] args) {
        Staross Staross = new Staross(121, "eau", "psy", 75, 85, 60);
        System.out.println(Staross);
    }
}
