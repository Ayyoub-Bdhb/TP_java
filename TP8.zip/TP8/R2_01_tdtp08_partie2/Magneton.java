public class Magneton extends Pokemon {

    public String getEspece() {
        return "Magnéton";
    }

    public Magneton(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Magnéton", "electrik", "", attPokemon, defPokemon, 70, pvPokemon);
    }

    public static void main(String[] args) {
        Magneton Magneton = new Magneton(82, "electrik", "", 60, 95, 50);
        System.out.println(Magneton);
    }
}
