public class Ortide extends Pokemon {

    public String getEspece() {
        return "Ortide";
    }

    public Ortide(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Ortide", "plante", "poison", attPokemon, defPokemon, 40, pvPokemon);
    }

    public static void main(String[] args) {
        Ortide Ortide = new Ortide(44, "plante", "poison", 65, 70, 60);
        System.out.println(Ortide);
    }
}
