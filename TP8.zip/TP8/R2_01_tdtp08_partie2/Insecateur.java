public class Insecateur extends Pokemon {

    public String getEspece() {
        return "Insécateur";
    }

    public Insecateur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Insécateur", "insecte", "vol", attPokemon, defPokemon, 105, pvPokemon);
    }

    public static void main(String[] args) {
        Insecateur Insecateur = new Insecateur(123, "insecte", "vol", 110, 80, 70);
        System.out.println(Insecateur);
    }
}
