public class Krabboss extends Pokemon {

    public String getEspece() {
        return "Krabboss";
    }

    public Krabboss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Krabboss", "eau", "", attPokemon, defPokemon, 75, pvPokemon);
    }

    public static void main(String[] args) {
        Krabboss Krabboss = new Krabboss(99, "eau", "", 130, 115, 55);
        System.out.println(Krabboss);
    }
}
