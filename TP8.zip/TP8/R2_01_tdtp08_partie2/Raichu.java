public class Raichu extends Pokemon {

    public String getEspece() {
        return "Raichu";
    }

    public Raichu(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Raichu", "electrik", "", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Raichu Raichu = new Raichu(26, "electrik", "", 90, 55, 60);
        System.out.println(Raichu);
    }
}
