public class Mew extends Pokemon {

    public String getEspece() {
        return "Mew";
    }

    public Mew(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Mew", "psy", "", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Mew Mew = new Mew(151, "psy", "", 100, 100, 100);
        System.out.println(Mew);
    }
}
