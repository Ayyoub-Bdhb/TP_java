public class Parasect extends Pokemon {

    public String getEspece() {
        return "Parasect";
    }

    public Parasect(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Parasect", "insecte", "plante", attPokemon, defPokemon, 30, pvPokemon);
    }

    public static void main(String[] args) {
        Parasect Parasect = new Parasect(47, "insecte", "plante", 95, 80, 60);
        System.out.println(Parasect);
    }
}
