public class Dracolosse extends Pokemon {

    public String getEspece() {
        return "Dracolosse";
    }

    public Dracolosse(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Dracolosse", "dragon", "vol", attPokemon, defPokemon, 80, pvPokemon);
    }

    public static void main(String[] args) {
        Dracolosse Dracolosse = new Dracolosse(149, "dragon", "vol", 134, 95, 91);
        System.out.println(Dracolosse);
    }
}
