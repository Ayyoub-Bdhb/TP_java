public class Osselait extends Pokemon {

    public String getEspece() {
        return "Osselait";
    }

    public Osselait(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Osselait", "sol", "", attPokemon, defPokemon, 35, pvPokemon);
    }

    public static void main(String[] args) {
        Osselait Osselait = new Osselait(104, "sol", "", 50, 95, 50);
        System.out.println(Osselait);
    }
}
