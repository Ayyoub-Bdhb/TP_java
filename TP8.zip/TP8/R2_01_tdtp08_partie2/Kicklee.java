public class Kicklee extends Pokemon {

    public String getEspece() {
        return "Kicklee";
    }

    public Kicklee(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Kicklee", "combat", "", attPokemon, defPokemon, 87, pvPokemon);
    }

    public static void main(String[] args) {
        Kicklee Kicklee = new Kicklee(106, "combat", "", 120, 53, 50);
        System.out.println(Kicklee);
    }
}
