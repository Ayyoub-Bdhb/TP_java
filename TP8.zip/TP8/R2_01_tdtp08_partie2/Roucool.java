public class Roucool extends Pokemon {

    public String getEspece() {
        return "Roucool";
    }

    public Roucool(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Roucool", "normal", "vol", attPokemon, defPokemon, 56, pvPokemon);
    }

    public static void main(String[] args) {
        Roucool Roucool = new Roucool(16, "normal", "vol", 45, 40, 40);
        System.out.println(Roucool);
    }
}
