public class Papilusion extends Pokemon {

    public String getEspece() {
        return "Papilusion";
    }

    public Papilusion(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Papilusion", "insecte", "vol", attPokemon, defPokemon, 70, pvPokemon);
    }

    public static void main(String[] args) {
        Papilusion Papilusion = new Papilusion(12, "insecte", "vol", 45, 50, 60);
        System.out.println(Papilusion);
    }
}
