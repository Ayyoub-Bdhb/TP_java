public class Rapasdepic extends Pokemon {

    public String getEspece() {
        return "Rapasdepic";
    }

    public Rapasdepic(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Rapasdepic", "normal", "vol", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Rapasdepic Rapasdepic = new Rapasdepic(22, "normal", "vol", 90, 65, 65);
        System.out.println(Rapasdepic);
    }
}
