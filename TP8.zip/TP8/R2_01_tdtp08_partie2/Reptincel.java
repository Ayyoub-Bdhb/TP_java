public class Reptincel extends Pokemon {

    public String getEspece() {
        return "Reptincel";
    }

    public Reptincel(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Reptincel", "feu", "", attPokemon, defPokemon, 80, pvPokemon);
    }

    public static void main(String[] args) {
        Reptincel Reptincel = new Reptincel(5, "feu", "", 64, 58, 58);
        System.out.println(Reptincel);
    }
}
