public class Abra extends Pokemon {

    public String getEspece() {
        return "Abra";
    }

    public Abra(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Abra", "psy", "", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Abra Abra = new Abra(63, "psy", "", 20, 15, 25);
        System.out.println(Abra);
    }
}
