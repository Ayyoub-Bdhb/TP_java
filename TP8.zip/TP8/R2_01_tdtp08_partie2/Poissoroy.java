public class Poissoroy extends Pokemon {

    public String getEspece() {
        return "Poissoroy";
    }

    public Poissoroy(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Poissoroy", "eau", "", attPokemon, defPokemon, 68, pvPokemon);
    }

    public static void main(String[] args) {
        Poissoroy Poissoroy = new Poissoroy(119, "eau", "", 92, 65, 80);
        System.out.println(Poissoroy);
    }
}
