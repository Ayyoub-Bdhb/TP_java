public class Nidoking extends Pokemon {

    public String getEspece() {
        return "Nidoking";
    }

    public Nidoking(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nidoking", "poison", "sol", attPokemon, defPokemon, 85, pvPokemon);
    }

    public static void main(String[] args) {
        Nidoking Nidoking = new Nidoking(34, "poison", "sol", 92, 77, 81);
        System.out.println(Nidoking);
    }
}
