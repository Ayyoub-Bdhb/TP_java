public class Coconfort extends Pokemon {

    public String getEspece() {
        return "Coconfort";
    }

    public Coconfort(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Coconfort", "insecte", "poison", attPokemon, defPokemon, 35, pvPokemon);
    }

    public static void main(String[] args) {
        Coconfort Coconfort = new Coconfort(14, "insecte", "poison", 25, 50, 45);
        System.out.println(Coconfort);
    }
}
