public class Machopeur extends Pokemon {

    public String getEspece() {
        return "Machopeur";
    }

    public Machopeur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Machopeur", "combat", "", attPokemon, defPokemon, 45, pvPokemon);
    }

    public static void main(String[] args) {
        Machopeur Machopeur = new Machopeur(67, "combat", "", 100, 70, 80);
        System.out.println(Machopeur);
    }
}
