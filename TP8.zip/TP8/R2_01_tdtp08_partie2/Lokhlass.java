public class Lokhlass extends Pokemon {

    public String getEspece() {
        return "Lokhlass";
    }

    public Lokhlass(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Lokhlass", "eau", "glace", attPokemon, defPokemon, 60, pvPokemon);
    }

    public static void main(String[] args) {
        Lokhlass Lokhlass = new Lokhlass(131, "eau", "glace", 85, 80, 130);
        System.out.println(Lokhlass);
    }
}
