public class Poissirene extends Pokemon {

    public String getEspece() {
        return "Poissirène";
    }

    public Poissirene(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Poissirène", "eau", "", attPokemon, defPokemon, 63, pvPokemon);
    }

    public static void main(String[] args) {
        Poissirene Poissirene = new Poissirene(118, "eau", "", 67, 60, 45);
        System.out.println(Poissirene);
    }
}
