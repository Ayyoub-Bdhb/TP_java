public class Dodrio extends Pokemon {

    public String getEspece() {
        return "Dodrio";
    }

    public Dodrio(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Dodrio", "normal", "vol", attPokemon, defPokemon, 100, pvPokemon);
    }

    public static void main(String[] args) {
        Dodrio Dodrio = new Dodrio(85, "normal", "vol", 110, 70, 60);
        System.out.println(Dodrio);
    }
}
