public class Smogo extends Pokemon {

    public String getEspece() {
        return "Smogo";
    }

    public Smogo(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Smogo", "poison", "", attPokemon, defPokemon, 35, pvPokemon);
    }

    public static void main(String[] args) {
        Smogo Smogo = new Smogo(109, "poison", "", 65, 95, 40);
        System.out.println(Smogo);
    }
}
