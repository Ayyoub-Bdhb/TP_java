public class Spectrum extends Pokemon {

    public String getEspece() {
        return "Spectrum";
    }

    public Spectrum(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Spectrum", "spectre", "poison", attPokemon, defPokemon, 95, pvPokemon);
    }

    public static void main(String[] args) {
        Spectrum Spectrum = new Spectrum(93, "spectre", "poison", 50, 45, 45);
        System.out.println(Spectrum);
    }
}
