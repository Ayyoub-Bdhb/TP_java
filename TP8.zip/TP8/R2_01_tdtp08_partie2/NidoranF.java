public class NidoranF extends Pokemon {

    public String getEspece() {
        return "Nidoran♀";
    }

    public NidoranF(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nidoran♀", "poison", "", attPokemon, defPokemon, 41, pvPokemon);
    }

    public static void main(String[] args) {
        NidoranF NidoranF = new NidoranF(29, "poison", "", 47, 52, 55);
        System.out.println(NidoranF);
    }
}
