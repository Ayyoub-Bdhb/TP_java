public class Rattatac extends Pokemon {

    public String getEspece() {
        return "Rattatac";
    }

    public Rattatac(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Rattatac", "normal", "", attPokemon, defPokemon, 97, pvPokemon);
    }

    public static void main(String[] args) {
        Rattatac Rattatac = new Rattatac(20, "normal", "", 81, 60, 55);
        System.out.println(Rattatac);
    }
}
