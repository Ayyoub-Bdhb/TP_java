public class Salameche extends Pokemon {

    public String getEspece() {
        return "Salamèche";
    }

    public Salameche(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Salamèche", "feu", "", attPokemon, defPokemon, 65, pvPokemon);
    }

    public static void main(String[] args) {
        Salameche Salameche = new Salameche(4, "feu", "", 52, 43, 39);
        System.out.println(Salameche);
    }
}
