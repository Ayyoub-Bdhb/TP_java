public class Goupix extends Pokemon {

    public String getEspece() {
        return "Goupix";
    }

    public Goupix(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Goupix", "feu", "", attPokemon, defPokemon, 65, pvPokemon);
    }

    public static void main(String[] args) {
        Goupix Goupix = new Goupix(37, "feu", "", 41, 40, 38);
        System.out.println(Goupix);
    }
}
