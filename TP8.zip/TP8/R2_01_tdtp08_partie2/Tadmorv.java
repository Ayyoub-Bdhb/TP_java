public class Tadmorv extends Pokemon {

    public String getEspece() {
        return "Tadmorv";
    }

    public Tadmorv(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Tadmorv", "poison", "", attPokemon, defPokemon, 25, pvPokemon);
    }

    public static void main(String[] args) {
        Tadmorv Tadmorv = new Tadmorv(88, "poison", "", 80, 50, 80);
        System.out.println(Tadmorv);
    }
}
