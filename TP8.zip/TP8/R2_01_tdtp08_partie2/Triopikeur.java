public class Triopikeur extends Pokemon {

    public String getEspece() {
        return "Triopikeur";
    }

    public Triopikeur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Triopikeur", "sol", "", attPokemon, defPokemon, 120, pvPokemon);
    }

    public static void main(String[] args) {
        Triopikeur Triopikeur = new Triopikeur(51, "sol", "", 80, 50, 35);
        System.out.println(Triopikeur);
    }
}
