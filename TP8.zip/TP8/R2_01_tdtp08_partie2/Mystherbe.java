public class Mystherbe extends Pokemon {

    public String getEspece() {
        return "Mystherbe";
    }

    public Mystherbe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Mystherbe", "plante", "poison", attPokemon, defPokemon, 30, pvPokemon);
    }

    public static void main(String[] args) {
        Mystherbe Mystherbe = new Mystherbe(43, "plante", "poison", 50, 55, 45);
        System.out.println(Mystherbe);
    }
}
