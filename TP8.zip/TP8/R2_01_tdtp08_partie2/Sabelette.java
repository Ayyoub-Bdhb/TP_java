public class Sabelette extends Pokemon {

    public String getEspece() {
        return "Sabelette";
    }

    public Sabelette(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Sabelette", "sol", "", attPokemon, defPokemon, 40, pvPokemon);
    }

    public static void main(String[] args) {
        Sabelette Sabelette = new Sabelette(27, "sol", "", 75, 85, 50);
        System.out.println(Sabelette);
    }
}
