public class Fantominus extends Pokemon {

    public String getEspece() {
        return "Fantominus";
    }

    public Fantominus(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Fantominus", "spectre", "poison", attPokemon, defPokemon, 80, pvPokemon);
    }

    public static void main(String[] args) {
        Fantominus Fantominus = new Fantominus(92, "spectre", "poison", 35, 30, 30);
        System.out.println(Fantominus);
    }
}
