public class Noeunoeuf extends Pokemon {

    public String getEspece() {
        return "Noeunoeuf";
    }

    public Noeunoeuf(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Noeunoeuf", "plante", "psy", attPokemon, defPokemon, 40, pvPokemon);
    }

    public static void main(String[] args) {
        Noeunoeuf Noeunoeuf = new Noeunoeuf(102, "plante", "psy", 40, 80, 60);
        System.out.println(Noeunoeuf);
    }
}
