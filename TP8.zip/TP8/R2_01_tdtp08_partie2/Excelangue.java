public class Excelangue extends Pokemon {

    public String getEspece() {
        return "Excelangue";
    }

    public Excelangue(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Excelangue", "normal", "", attPokemon, defPokemon, 30, pvPokemon);
    }

    public static void main(String[] args) {
        Excelangue Excelangue = new Excelangue(108, "normal", "", 55, 75, 90);
        System.out.println(Excelangue);
    }
}
