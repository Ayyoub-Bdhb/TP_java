public class Chetiflor extends Pokemon {

    public String getEspece() {
        return "Chétiflor";
    }

    public Chetiflor(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Chétiflor", "plante", "poison", attPokemon, defPokemon, 40, pvPokemon);
    }

    public static void main(String[] args) {
        Chetiflor Chetiflor = new Chetiflor(69, "plante", "poison", 75, 35, 50);
        System.out.println(Chetiflor);
    }
}
