public class Hypnomade extends Pokemon {

    public String getEspece() {
        return "Hypnomade";
    }

    public Hypnomade(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Hypnomade", "psy", "", attPokemon, defPokemon, 67, pvPokemon);
    }

    public static void main(String[] args) {
        Hypnomade Hypnomade = new Hypnomade(97, "psy", "", 73, 70, 85);
        System.out.println(Hypnomade);
    }
}
