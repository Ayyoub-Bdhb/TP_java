public class Ptitard extends Pokemon {

    public String getEspece() {
        return "Ptitard";
    }

    public Ptitard(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Ptitard", "eau", "", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Ptitard Ptitard = new Ptitard(60, "eau", "", 50, 40, 40);
        System.out.println(Ptitard);
    }
}
