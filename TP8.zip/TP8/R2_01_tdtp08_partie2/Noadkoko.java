public class Noadkoko extends Pokemon {

    public String getEspece() {
        return "Noadkoko";
    }

    public Noadkoko(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Noadkoko", "plante", "psy", attPokemon, defPokemon, 55, pvPokemon);
    }

    public static void main(String[] args) {
        Noadkoko Noadkoko = new Noadkoko(103, "plante", "psy", 95, 85, 95);
        System.out.println(Noadkoko);
    }
}
