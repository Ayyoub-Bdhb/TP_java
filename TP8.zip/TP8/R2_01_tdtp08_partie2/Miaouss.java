public class Miaouss extends Pokemon {

    public String getEspece() {
        return "Miaouss";
    }

    public Miaouss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Miaouss", "normal", "", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Miaouss Miaouss = new Miaouss(52, "normal", "", 45, 35, 40);
        System.out.println(Miaouss);
    }
}
