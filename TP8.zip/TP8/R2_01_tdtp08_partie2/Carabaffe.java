public class Carabaffe extends Pokemon {

    public String getEspece() {
        return "Carabaffe";
    }

    public Carabaffe(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Carabaffe", "eau", "", attPokemon, defPokemon, 58, pvPokemon);
    }

    public static void main(String[] args) {
        Carabaffe Carabaffe = new Carabaffe(8, "eau", "", 63, 80, 59);
        System.out.println(Carabaffe);
    }
}
