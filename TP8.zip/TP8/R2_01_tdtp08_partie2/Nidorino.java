public class Nidorino extends Pokemon {

    public String getEspece() {
        return "Nidorino";
    }

    public Nidorino(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nidorino", "poison", "", attPokemon, defPokemon, 65, pvPokemon);
    }

    public static void main(String[] args) {
        Nidorino Nidorino = new Nidorino(33, "poison", "", 72, 57, 61);
        System.out.println(Nidorino);
    }
}
