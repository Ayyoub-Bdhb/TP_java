public class Tentacool extends Pokemon {

    public String getEspece() {
        return "Tentacool";
    }

    public Tentacool(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Tentacool", "eau", "poison", attPokemon, defPokemon, 70, pvPokemon);
    }

    public static void main(String[] args) {
        Tentacool Tentacool = new Tentacool(72, "eau", "poison", 40, 35, 40);
        System.out.println(Tentacool);
    }
}
