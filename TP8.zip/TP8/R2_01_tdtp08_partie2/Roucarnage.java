public class Roucarnage extends Pokemon {

    public String getEspece() {
        return "Roucarnage";
    }

    public Roucarnage(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Roucarnage", "normal", "vol", attPokemon, defPokemon, 91, pvPokemon);
    }

    public static void main(String[] args) {
        Roucarnage Roucarnage = new Roucarnage(18, "normal", "vol", 80, 75, 83);
        System.out.println(Roucarnage);
    }
}
