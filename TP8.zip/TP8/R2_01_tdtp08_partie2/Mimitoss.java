public class Mimitoss extends Pokemon {

    public String getEspece() {
        return "Mimitoss";
    }

    public Mimitoss(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Mimitoss", "insecte", "poison", attPokemon, defPokemon, 45, pvPokemon);
    }

    public static void main(String[] args) {
        Mimitoss Mimitoss = new Mimitoss(48, "insecte", "poison", 55, 50, 60);
        System.out.println(Mimitoss);
    }
}
