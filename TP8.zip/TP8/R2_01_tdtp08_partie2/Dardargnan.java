public class Dardargnan extends Pokemon {

    public String getEspece() {
        return "Dardargnan";
    }

    public Dardargnan(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Dardargnan", "insecte", "poison", attPokemon, defPokemon, 75, pvPokemon);
    }

    public static void main(String[] args) {
        Dardargnan Dardargnan = new Dardargnan(15, "insecte", "poison", 80, 40, 65);
        System.out.println(Dardargnan);
    }
}
