public class Rondoudou extends Pokemon {

    public String getEspece() {
        return "Rondoudou";
    }

    public Rondoudou(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Rondoudou", "normal", "", attPokemon, defPokemon, 20, pvPokemon);
    }

    public static void main(String[] args) {
        Rondoudou Rondoudou = new Rondoudou(39, "normal", "", 45, 20, 115);
        System.out.println(Rondoudou);
    }
}
