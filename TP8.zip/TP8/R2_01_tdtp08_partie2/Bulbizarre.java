public class Bulbizarre extends Pokemon {

    public String getEspece() {
        return "Bulbizarre";
    }

    public Bulbizarre(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Bulbizarre", "plante", "poison", attPokemon, defPokemon, 45, pvPokemon);
    }

    public static void main(String[] args) {
        Bulbizarre Bulbizarre = new Bulbizarre(1, "plante", "poison", 49, 49, 45);
        System.out.println(Bulbizarre);
    }
}
