public class Ossatueur extends Pokemon {

    public String getEspece() {
        return "Ossatueur";
    }

    public Ossatueur(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Ossatueur", "sol", "", attPokemon, defPokemon, 45, pvPokemon);
    }

    public static void main(String[] args) {
        Ossatueur Ossatueur = new Ossatueur(105, "sol", "", 80, 110, 60);
        System.out.println(Ossatueur);
    }
}
