public class Doduo extends Pokemon {

    public String getEspece() {
        return "Doduo";
    }

    public Doduo(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Doduo", "normal", "vol", attPokemon, defPokemon, 75, pvPokemon);
    }

    public static void main(String[] args) {
        Doduo Doduo = new Doduo(84, "normal", "vol", 85, 45, 35);
        System.out.println(Doduo);
    }
}
