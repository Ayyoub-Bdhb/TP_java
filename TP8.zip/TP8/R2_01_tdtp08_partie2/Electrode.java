public class Electrode extends Pokemon {

    public String getEspece() {
        return "Électrode";
    }

    public Electrode(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Électrode", "electrik", "", attPokemon, defPokemon, 140, pvPokemon);
    }

    public static void main(String[] args) {
        Electrode Electrode = new Electrode(101, "electrik", "", 50, 70, 60);
        System.out.println(Electrode);
    }
}
