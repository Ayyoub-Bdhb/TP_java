public class Machoc extends Pokemon {

    public String getEspece() {
        return "Machoc";
    }

    public Machoc(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Machoc", "combat", "", attPokemon, defPokemon, 35, pvPokemon);
    }

    public static void main(String[] args) {
        Machoc Machoc = new Machoc(66, "combat", "", 80, 50, 70);
        System.out.println(Machoc);
    }
}
