public class Abo extends Pokemon {

    public String getEspece() {
        return "Abo";
    }

    public Abo(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Abo", "poison", "", attPokemon, defPokemon, 55, pvPokemon);
    }

    public static void main(String[] args) {
        Abo Abo = new Abo(23, "poison", "", 60, 44, 35);
        System.out.println(Abo);
    }
}
