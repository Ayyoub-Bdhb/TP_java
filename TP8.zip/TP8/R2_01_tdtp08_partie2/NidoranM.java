public class NidoranM extends Pokemon {

    public String getEspece() {
        return "Nidoran♂";
    }

    public NidoranM(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Nidoran♂", "poison", "", attPokemon, defPokemon, 50, pvPokemon);
    }

    public static void main(String[] args) {
        NidoranM NidoranM = new NidoranM(32, "poison", "", 57, 40, 46);
        System.out.println(NidoranM);
    }
}
