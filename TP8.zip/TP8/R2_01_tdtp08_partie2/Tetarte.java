public class Tetarte extends Pokemon {

    public String getEspece() {
        return "Têtarte";
    }

    public Tetarte(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Têtarte", "eau", "", attPokemon, defPokemon, 90, pvPokemon);
    }

    public static void main(String[] args) {
        Tetarte Tetarte = new Tetarte(61, "eau", "", 65, 65, 65);
        System.out.println(Tetarte);
    }
}
