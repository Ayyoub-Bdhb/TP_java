public class Caninos extends Pokemon {

    public String getEspece() {
        return "Caninos";
    }

    public Caninos(int numPokemon, String typePokemon1, String typePokemon2, int attPokemon, int defPokemon, int pvPokemon) {
        super(numPokemon, "Caninos", "feu", "", attPokemon, defPokemon, 60, pvPokemon);
    }

    public static void main(String[] args) {
        Caninos Caninos = new Caninos(58, "feu", "", 70, 45, 55);
        System.out.println(Caninos);
    }
}
